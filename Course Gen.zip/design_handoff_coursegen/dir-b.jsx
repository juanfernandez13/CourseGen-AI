/* Direction B — SaaS denso dark · Linear/Vercel vibes */

const B_W = 1180;
const B_H = 760;

const BNav = ({ active }) => (
  <nav style={{
    height: 44, borderBottom: '1px solid var(--line)',
    display: 'flex', alignItems: 'center', padding: '0 16px',
    background: 'var(--surface)', flexShrink: 0,
  }}>
    <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginRight: 24 }}>
      <div style={{ width: 18, height: 18, borderRadius: 4, background: 'linear-gradient(135deg, var(--accent), var(--accent-2))', position: 'relative' }}>
        <div style={{ position: 'absolute', inset: 4, background: 'var(--surface)', borderRadius: 1.5 }}/>
      </div>
      <span style={{ fontSize: 13, fontWeight: 600, letterSpacing: -0.2 }}>CourseGen</span>
      <span style={{ fontSize: 10.5, color: 'var(--ink-3)', fontFamily: 'var(--mono)', padding: '1px 6px', border: '1px solid var(--line)', borderRadius: 3 }}>v0.4</span>
    </div>
    <div style={{ display: 'flex', gap: 2, fontSize: 12.5 }}>
      {[['Disciplinas', 'home'], ['Nova', 'new'], ['Templates', 'tpl'], ['Atividade', 'act']].map(([l, k]) => (
        <button key={k} className="btn-reset" style={{
          padding: '6px 10px', borderRadius: 5,
          background: active === k ? 'var(--surface-3)' : 'transparent',
          color: active === k ? 'var(--ink)' : 'var(--ink-2)',
          fontWeight: active === k ? 500 : 400,
        }}>{l}</button>
      ))}
    </div>
    <div style={{ marginLeft: 'auto', display: 'flex', alignItems: 'center', gap: 10 }}>
      <div style={{
        display: 'flex', alignItems: 'center', gap: 8,
        padding: '4px 10px', background: 'var(--surface-2)',
        borderRadius: 5, border: '1px solid var(--line)',
        fontSize: 11.5, color: 'var(--ink-3)',
      }}>
        <span style={{ fontFamily: 'var(--mono)' }}>⌘K</span>
        <span style={{ width: 1, height: 12, background: 'var(--line)' }}/>
        <span>buscar…</span>
      </div>
      <button className="btn-reset" style={{ padding: '4px 8px', borderRadius: 5, fontSize: 12, color: 'var(--ink-2)' }}>⚙</button>
      <div style={{ width: 22, height: 22, borderRadius: '50%', background: 'linear-gradient(135deg, #f472b6, #818cf8)', fontSize: 10, color: 'white', display: 'grid', placeItems: 'center', fontWeight: 600 }}>JF</div>
    </div>
  </nav>
);

const BBadge = ({ children, tone = 'default' }) => {
  const t = {
    default: ['var(--surface-3)', 'var(--ink-2)', 'var(--line)'],
    accent: [ 'var(--accent-soft)', 'var(--accent-ink)', 'rgba(129,140,248,0.3)'],
    ok: ['rgba(74,222,128,0.1)', 'var(--ok)', 'rgba(74,222,128,0.25)'],
    warn: ['rgba(251,191,36,0.1)', 'var(--warn)', 'rgba(251,191,36,0.25)'],
    danger: ['rgba(248,113,113,0.1)', 'var(--danger)', 'rgba(248,113,113,0.25)'],
  }[tone];
  return (
    <span style={{
      display: 'inline-flex', alignItems: 'center', gap: 5,
      padding: '2px 8px', borderRadius: 4,
      background: t[0], color: t[1], border: `1px solid ${t[2]}`,
      fontSize: 10.5, fontFamily: 'var(--mono)', letterSpacing: 0.2, textTransform: 'uppercase',
    }}>{children}</span>
  );
};

/* ── B1 · Home (Disciplinas) ───────────────────── */
const B_Home = () => (
  <div className="ab dir-b">
    <BNav active="home" />
    <div style={{ flex: 1, display: 'flex', flexDirection: 'column', overflow: 'hidden' }}>
      <div style={{ padding: '20px 24px 16px', borderBottom: '1px solid var(--line)', display: 'flex', justifyContent: 'space-between', alignItems: 'flex-end' }}>
        <div>
          <div style={{ fontSize: 11, color: 'var(--ink-3)', fontFamily: 'var(--mono)', marginBottom: 6 }}>WORKSPACE / IFCE-MARACANAÚ</div>
          <h1 style={{ fontSize: 22, margin: 0, fontWeight: 600, letterSpacing: -0.4 }}>Disciplinas</h1>
        </div>
        <div style={{ display: 'flex', gap: 8 }}>
          <button className="btn-reset" style={{ padding: '6px 12px', borderRadius: 5, border: '1px solid var(--line-2)', background: 'var(--surface-2)', fontSize: 12 }}>Importar Matriz</button>
          <button className="btn-reset" style={{ padding: '6px 12px', borderRadius: 5, background: 'var(--ink)', color: 'var(--bg)', fontSize: 12, fontWeight: 500 }}>+ Nova</button>
        </div>
      </div>

      {/* Filter row */}
      <div style={{ padding: '10px 24px', borderBottom: '1px solid var(--line)', display: 'flex', gap: 6, fontSize: 11.5, color: 'var(--ink-2)', alignItems: 'center' }}>
        {['Todas (12)', 'Pronto (8)', 'Em revisão (3)', 'Falhou (1)'].map((f, i) => (
          <button key={i} className="btn-reset" style={{
            padding: '4px 9px', borderRadius: 4,
            background: i === 0 ? 'var(--surface-3)' : 'transparent',
            color: i === 0 ? 'var(--ink)' : 'var(--ink-2)',
            border: i === 0 ? '1px solid var(--line-2)' : '1px solid transparent',
          }}>{f}</button>
        ))}
        <div style={{ marginLeft: 'auto', display: 'flex', gap: 8, alignItems: 'center' }}>
          <span style={{ fontFamily: 'var(--mono)', fontSize: 10.5, color: 'var(--ink-3)' }}>ordem: recente ↓</span>
        </div>
      </div>

      {/* Table */}
      <div style={{ flex: 1, overflow: 'auto' }}>
        <div style={{
          display: 'grid', gridTemplateColumns: '24px 2fr 1fr 90px 100px 110px 30px',
          padding: '8px 24px', borderBottom: '1px solid var(--line)',
          fontSize: 10.5, fontFamily: 'var(--mono)', color: 'var(--ink-3)',
          letterSpacing: 0.5, textTransform: 'uppercase',
        }}>
          <div></div><div>nome</div><div>código</div><div>carga</div><div>status</div><div>atualizado</div><div></div>
        </div>
        {[
          ['Programação Orientada a Objetos', 'TADS-POO', '80h', 'pronto', '2h', 'ok'],
          ['Banco de Dados II', 'TADS-BDII', '60h', 'revisão', 'ontem', 'warn'],
          ['Redes de Computadores', 'TADS-REDES', '80h', 'pronto', '3 dias', 'ok'],
          ['Engenharia de Software', 'TADS-ES', '60h', 'pronto', '1 sem', 'ok'],
          ['Algoritmos e Estruturas de Dados', 'TADS-AED', '80h', 'falhou', '1 sem', 'danger'],
          ['Sistemas Operacionais', 'TADS-SO', '60h', 'pronto', '2 sem', 'ok'],
        ].map((r, i) => (
          <div key={i} style={{
            display: 'grid', gridTemplateColumns: '24px 2fr 1fr 90px 100px 110px 30px',
            padding: '11px 24px', borderBottom: '1px solid var(--line)',
            fontSize: 12.5, alignItems: 'center', cursor: 'pointer',
          }}>
            <div style={{ width: 6, height: 6, borderRadius: 1, background: r[5] === 'ok' ? 'var(--ok)' : r[5] === 'warn' ? 'var(--warn)' : 'var(--danger)' }}/>
            <div style={{ color: 'var(--ink)', fontWeight: 500 }}>{r[0]}</div>
            <div style={{ fontFamily: 'var(--mono)', fontSize: 11, color: 'var(--ink-3)' }}>{r[1]}</div>
            <div style={{ fontFamily: 'var(--mono)', fontSize: 11, color: 'var(--ink-2)' }}>{r[2]}</div>
            <div><BBadge tone={r[5] === 'ok' ? 'ok' : r[5] === 'warn' ? 'warn' : 'danger'}>{r[3]}</BBadge></div>
            <div style={{ fontSize: 11, color: 'var(--ink-3)' }}>{r[4]}</div>
            <div style={{ color: 'var(--ink-3)' }}>›</div>
          </div>
        ))}
      </div>
    </div>
  </div>
);

/* ── B2 · Settings ─────────────────────────────── */
const B_Settings = () => (
  <div className="ab dir-b">
    <BNav active="" />
    <div style={{ flex: 1, display: 'grid', gridTemplateColumns: '200px 1fr', overflow: 'hidden' }}>
      <aside style={{ borderRight: '1px solid var(--line)', padding: '20px 12px', background: 'var(--surface)' }}>
        <div style={{ fontSize: 10.5, fontFamily: 'var(--mono)', color: 'var(--ink-3)', textTransform: 'uppercase', letterSpacing: 0.5, padding: '6px 10px 8px' }}>Settings</div>
        {['Geral', 'Modelos de IA', 'Moodle', 'Colaboração', 'Atalhos', 'Faturamento'].map((s, i) => (
          <button key={i} className="btn-reset" style={{
            display: 'block', width: '100%', textAlign: 'left',
            padding: '6px 10px', borderRadius: 5, fontSize: 12.5,
            background: i === 1 ? 'var(--surface-3)' : 'transparent',
            color: i === 1 ? 'var(--ink)' : 'var(--ink-2)',
            fontWeight: i === 1 ? 500 : 400, marginBottom: 1,
          }}>{s}</button>
        ))}
      </aside>

      <main style={{ overflow: 'auto', padding: '28px 36px' }}>
        <h1 style={{ fontSize: 20, margin: 0, fontWeight: 600, letterSpacing: -0.3 }}>Modelos de IA</h1>
        <p style={{ fontSize: 13, color: 'var(--ink-2)', marginTop: 6, marginBottom: 24 }}>
          Configure provedores de IA. Suas chaves ficam no localStorage e nunca passam pelo servidor.
        </p>

        {/* Active model selector */}
        <div style={{ background: 'var(--surface)', border: '1px solid var(--line)', borderRadius: 6, padding: '14px 16px', marginBottom: 18, display: 'flex', alignItems: 'center', gap: 12 }}>
          <span style={{ fontSize: 12, color: 'var(--ink-2)' }}>Modelo padrão para extração</span>
          <div style={{ flex: 1 }}/>
          <div style={{
            display: 'flex', gap: 0,
            border: '1px solid var(--line)', borderRadius: 5, overflow: 'hidden',
          }}>
            {[
              ['Gemini 2.5 Flash', true],
              ['GPT-4.1', false],
              ['Claude Sonnet 4.5', false],
            ].map(([l, on], i) => (
              <button key={i} className="btn-reset" style={{
                padding: '6px 12px', fontSize: 11.5,
                background: on ? 'var(--surface-3)' : 'transparent',
                color: on ? 'var(--ink)' : 'var(--ink-3)',
                borderRight: i < 2 ? '1px solid var(--line)' : 'none',
                fontFamily: 'var(--mono)',
              }}>{l}</button>
            ))}
          </div>
        </div>

        {/* Provider list */}
        <div style={{ background: 'var(--surface)', border: '1px solid var(--line)', borderRadius: 6, overflow: 'hidden' }}>
          {[
            { brand: 'gemini', name: 'Google Gemini', model: 'gemini-2.5-flash', active: true, fallback: true, masked: 'AIza••••••••••••••a3F2', color: '#4285f4' },
            { brand: 'openai', name: 'OpenAI', model: 'gpt-4.1 · o1 · gpt-4o', active: false, masked: '', color: '#10a37f' },
            { brand: 'claude', name: 'Anthropic', model: 'claude-sonnet-4.5 · opus', active: false, masked: '', color: '#d97757' },
          ].map((p, i) => (
            <div key={i} style={{ padding: '16px 18px', borderBottom: i < 2 ? '1px solid var(--line)' : 'none' }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 10 }}>
                <div style={{ width: 26, height: 26, borderRadius: 5, background: p.color, opacity: 0.85, display: 'grid', placeItems: 'center', color: 'white', fontSize: 11, fontWeight: 700 }}>
                  {p.brand[0].toUpperCase()}
                </div>
                <div style={{ flex: 1 }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                    <span style={{ fontSize: 13, fontWeight: 500 }}>{p.name}</span>
                    {p.active && <BBadge tone="ok">conectado</BBadge>}
                    {p.fallback && <BBadge tone="default">fallback servidor</BBadge>}
                  </div>
                  <div style={{ fontFamily: 'var(--mono)', fontSize: 10.5, color: 'var(--ink-3)', marginTop: 2 }}>{p.model}</div>
                </div>
                <button className="btn-reset" style={{ fontSize: 11, color: 'var(--ink-3)' }}>docs ↗</button>
              </div>
              <div style={{
                display: 'flex', gap: 6, alignItems: 'center',
                background: 'var(--surface-2)', border: '1px solid var(--line)',
                borderRadius: 5, padding: '6px 10px',
              }}>
                <span style={{ fontFamily: 'var(--mono)', fontSize: 10.5, color: 'var(--ink-3)' }}>API_KEY</span>
                <span style={{ width: 1, height: 14, background: 'var(--line)' }}/>
                <input
                  defaultValue={p.masked}
                  placeholder={p.masked ? '' : `cole sua chave ${p.name}`}
                  style={{
                    flex: 1, border: 0, outline: 0, background: 'transparent',
                    fontFamily: 'var(--mono)', fontSize: 12, color: 'var(--ink)',
                  }}
                />
                {p.masked && <button className="btn-reset" style={{ fontFamily: 'var(--mono)', fontSize: 10, color: 'var(--ink-3)', padding: '2px 6px', border: '1px solid var(--line)', borderRadius: 3 }}>show</button>}
                <button className="btn-reset" style={{ fontFamily: 'var(--mono)', fontSize: 10, color: 'var(--ink)', padding: '2px 6px', border: '1px solid var(--line-2)', borderRadius: 3, background: p.masked ? 'transparent' : 'var(--accent-soft)' }}>{p.masked ? 'update' : 'save'}</button>
              </div>
            </div>
          ))}
        </div>

        <div style={{
          marginTop: 14, padding: '10px 14px', background: 'var(--accent-soft)',
          border: '1px solid rgba(129,140,248,0.25)', borderRadius: 6,
          fontSize: 11.5, color: 'var(--accent-ink)', display: 'flex', alignItems: 'center', gap: 8,
        }}>
          <span style={{ fontFamily: 'var(--mono)' }}>ⓘ</span>
          Sem chave própria configurada, o app cai automaticamente na <span style={{ fontFamily: 'var(--mono)', fontSize: 10.5 }}>GEMINI_KEY</span> do servidor (limite mensal compartilhado: 1k requests).
        </div>
      </main>
    </div>
  </div>
);

/* ── B3 · Upload ───────────────────────────────── */
const B_Upload = () => (
  <div className="ab dir-b">
    <BNav active="new" />

    {/* Stepper */}
    <div style={{ height: 38, borderBottom: '1px solid var(--line)', display: 'flex', alignItems: 'center', padding: '0 24px', gap: 10, fontSize: 11.5, fontFamily: 'var(--mono)', textTransform: 'uppercase', letterSpacing: 0.5 }}>
      <span style={{ color: 'var(--ink)', display: 'flex', alignItems: 'center', gap: 6 }}>
        <span style={{ width: 14, height: 14, borderRadius: '50%', background: 'var(--accent)', color: 'var(--bg)', display: 'grid', placeItems: 'center', fontSize: 9, fontWeight: 700 }}>1</span>
        upload
      </span>
      <span style={{ color: 'var(--ink-3)' }}>/</span>
      <span style={{ color: 'var(--ink-3)', display: 'flex', alignItems: 'center', gap: 6 }}>
        <span style={{ width: 14, height: 14, borderRadius: '50%', border: '1px solid var(--line-2)', display: 'grid', placeItems: 'center', fontSize: 9 }}>2</span>
        revisão
      </span>
      <span style={{ color: 'var(--ink-3)' }}>/</span>
      <span style={{ color: 'var(--ink-3)', display: 'flex', alignItems: 'center', gap: 6 }}>
        <span style={{ width: 14, height: 14, borderRadius: '50%', border: '1px solid var(--line-2)', display: 'grid', placeItems: 'center', fontSize: 9 }}>3</span>
        download
      </span>
      <div style={{ marginLeft: 'auto', color: 'var(--ink-3)' }}>esc para cancelar</div>
    </div>

    <main style={{ flex: 1, overflow: 'auto', padding: '28px 24px' }}>
      <h1 style={{ fontSize: 22, margin: 0, fontWeight: 600, letterSpacing: -0.4 }}>Anexar documentos</h1>
      <p style={{ fontSize: 13, color: 'var(--ink-2)', marginTop: 4, marginBottom: 22 }}>
        Matriz DE é obrigatória. Quizzes e tarefas, opcionais. Tamanho máximo 20 MB por arquivo.
      </p>

      <div style={{ display: 'grid', gridTemplateColumns: '1.4fr 1fr 1fr', gap: 12, marginBottom: 16 }}>
        {/* Matriz - filled */}
        <div style={{ background: 'var(--surface)', border: '1px solid var(--accent)', borderRadius: 6, padding: '14px 16px', position: 'relative' }}>
          <div style={{ position: 'absolute', top: -1, left: 12, padding: '0 6px', background: 'var(--bg)', fontSize: 9.5, fontFamily: 'var(--mono)', color: 'var(--accent)', letterSpacing: 0.5, textTransform: 'uppercase' }}>obrigatório</div>
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 4, marginTop: 4 }}>
            <div style={{ fontSize: 13, fontWeight: 500 }}>Matriz DE</div>
            <BBadge tone="ok">extraindo · 87%</BBadge>
          </div>
          <div style={{ fontSize: 11.5, color: 'var(--ink-3)' }}>Documento de planejamento da disciplina</div>

          {/* Progress */}
          <div style={{ marginTop: 14, marginBottom: 6, height: 3, background: 'var(--surface-3)', borderRadius: 2, overflow: 'hidden' }}>
            <div style={{ width: '87%', height: '100%', background: 'linear-gradient(90deg, var(--accent), var(--accent-2))' }}/>
          </div>

          <div style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '10px 0 0', fontFamily: 'var(--mono)', fontSize: 11 }}>
            <div style={{ width: 24, height: 30, borderRadius: 2, background: 'var(--accent-soft)', border: '1px solid rgba(129,140,248,0.3)', color: 'var(--accent)', fontSize: 8, display: 'grid', placeItems: 'center', fontWeight: 700 }}>DOC</div>
            <div style={{ flex: 1, color: 'var(--ink)' }}>matriz-poo-2026.1.docx</div>
            <div style={{ color: 'var(--ink-3)' }}>124 KB</div>
            <button className="btn-reset" style={{ color: 'var(--ink-3)', fontSize: 11 }}>×</button>
          </div>
        </div>

        {/* Quizzes */}
        <div style={{ background: 'var(--surface)', border: '1px solid var(--line)', borderRadius: 6, padding: '14px 16px', position: 'relative' }}>
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 4 }}>
            <div style={{ fontSize: 13, fontWeight: 500 }}>Quizzes</div>
            <BBadge>2 arquivos</BBadge>
          </div>
          <div style={{ fontSize: 11.5, color: 'var(--ink-3)' }}>Banco de questões para os quizzes</div>
          <div style={{ marginTop: 14, display: 'flex', flexDirection: 'column', gap: 5, fontFamily: 'var(--mono)', fontSize: 11 }}>
            {['quiz-unidade-1.docx', 'quiz-unidade-2.docx'].map((n, i) => (
              <div key={i} style={{ display: 'flex', alignItems: 'center', gap: 8, padding: '5px 8px', background: 'var(--surface-2)', borderRadius: 3 }}>
                <span style={{ color: 'var(--ink-3)' }}>›</span>
                <span style={{ flex: 1, color: 'var(--ink)' }}>{n}</span>
                <span style={{ color: 'var(--ink-3)' }}>×</span>
              </div>
            ))}
            <button className="btn-reset" style={{ padding: '5px 8px', textAlign: 'left', color: 'var(--ink-3)', fontSize: 11 }}>+ adicionar</button>
          </div>
        </div>

        {/* Tarefas - dropzone empty */}
        <div style={{ border: '1px dashed var(--line-2)', borderRadius: 6, padding: '14px 16px' }}>
          <div style={{ fontSize: 13, fontWeight: 500, marginBottom: 4 }}>Tarefas</div>
          <div style={{ fontSize: 11.5, color: 'var(--ink-3)' }}>Enunciados de atividades de entrega</div>
          <div style={{
            marginTop: 18, height: 90, display: 'flex', flexDirection: 'column',
            alignItems: 'center', justifyContent: 'center', gap: 6,
            background: 'var(--surface)', borderRadius: 4, fontSize: 11.5, color: 'var(--ink-3)',
          }}>
            <div style={{ fontSize: 18, color: 'var(--ink-3)' }}>↑</div>
            <div>arraste ou <span style={{ color: 'var(--accent)', textDecoration: 'underline' }}>clique para selecionar</span></div>
            <div style={{ fontFamily: 'var(--mono)', fontSize: 10, color: 'var(--ink-3)' }}>.docx · .pdf</div>
          </div>
        </div>
      </div>

      {/* Live extraction log */}
      <div style={{ background: 'var(--surface)', border: '1px solid var(--line)', borderRadius: 6, overflow: 'hidden' }}>
        <div style={{ padding: '8px 14px', borderBottom: '1px solid var(--line)', display: 'flex', alignItems: 'center', gap: 8, fontSize: 11, fontFamily: 'var(--mono)', color: 'var(--ink-2)' }}>
          <span style={{ width: 8, height: 8, borderRadius: '50%', background: 'var(--accent)', boxShadow: '0 0 0 3px rgba(129,140,248,0.2)' }}/>
          extraindo · gemini-2.5-flash
          <span style={{ marginLeft: 'auto', color: 'var(--ink-3)' }}>elapsed 00:18</span>
        </div>
        <div style={{ padding: '10px 14px', fontFamily: 'var(--mono)', fontSize: 11, lineHeight: 1.7, color: 'var(--ink-2)' }}>
          {[
            ['00:02', 'parser', 'lendo matriz-poo-2026.1.docx (124 KB)'],
            ['00:04', 'gemini', 'identificou: nome, código, ementa, 8 objetivos'],
            ['00:09', 'gemini', 'extraiu cronograma · 3 unidades · 13 atividades'],
            ['00:14', 'linker', 'associando quiz-unidade-1.docx → Q1 (Unidade 1)'],
            ['00:17', 'linker', 'associando quiz-unidade-2.docx → Q2 (Unidade 2)'],
          ].map((r, i) => (
            <div key={i} style={{ display: 'grid', gridTemplateColumns: '50px 70px 1fr', gap: 10 }}>
              <span style={{ color: 'var(--ink-3)' }}>{r[0]}</span>
              <span style={{ color: 'var(--accent)' }}>{r[1]}</span>
              <span>{r[2]}</span>
            </div>
          ))}
          <div style={{ display: 'grid', gridTemplateColumns: '50px 70px 1fr', gap: 10, opacity: 0.6 }}>
            <span style={{ color: 'var(--ink-3)' }}>00:18</span>
            <span style={{ color: 'var(--accent)' }}>gemini</span>
            <span>estruturando avaliações<span style={{ animation: 'blink 1s infinite' }}>▎</span></span>
          </div>
        </div>
      </div>

      <div style={{ marginTop: 18, display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <div style={{ fontFamily: 'var(--mono)', fontSize: 11, color: 'var(--ink-3)' }}>~12s para concluir</div>
        <div style={{ display: 'flex', gap: 8 }}>
          <button className="btn-reset" style={{ padding: '6px 14px', borderRadius: 5, border: '1px solid var(--line-2)', background: 'var(--surface-2)', fontSize: 12, color: 'var(--ink-2)' }}>Cancelar</button>
          <button className="btn-reset" style={{ padding: '6px 14px', borderRadius: 5, background: 'var(--ink-2)', color: 'var(--bg)', fontSize: 12, fontWeight: 500, opacity: 0.5 }}>Aguardando…</button>
        </div>
      </div>
    </main>
  </div>
);

/* ── B4 · Review ───────────────────────────────── */
const B_Review = () => (
  <div className="ab dir-b">
    <BNav active="new" />
    <div style={{ flex: 1, display: 'grid', gridTemplateColumns: '260px 1fr 280px', overflow: 'hidden' }}>
      {/* Tree */}
      <aside style={{ borderRight: '1px solid var(--line)', overflow: 'auto', background: 'var(--surface)' }}>
        <div style={{ padding: '12px 14px', borderBottom: '1px solid var(--line)', display: 'flex', alignItems: 'center', gap: 8 }}>
          <BBadge tone="accent">JSON</BBadge>
          <span style={{ fontSize: 12, fontWeight: 500 }}>poo-2026.1</span>
          <span style={{ marginLeft: 'auto', fontFamily: 'var(--mono)', fontSize: 10, color: 'var(--ink-3)' }}>v3</span>
        </div>
        <div style={{ padding: 8, fontFamily: 'var(--mono)', fontSize: 11.5 }}>
          {[
            { l: 'identificacao', n: 6, depth: 0, ok: true },
            { l: 'ementa', n: 1, depth: 0, warn: true },
            { l: 'objetivos', n: 8, depth: 0, ok: true },
            { l: 'unidades[]', n: 3, depth: 0, expand: true },
            { l: '[0] Conceitos OO', n: 4, depth: 1, active: true },
            { l: '└ atividades[]', n: 4, depth: 2 },
            { l: '[1] Herança', n: 5, depth: 1 },
            { l: '[2] Polimorfismo', n: 4, depth: 1 },
            { l: 'avaliacoes', n: 3, depth: 0 },
          ].map((n, i) => (
            <div key={i} style={{
              padding: '4px 8px', paddingLeft: 8 + n.depth * 14,
              display: 'flex', alignItems: 'center', gap: 6,
              background: n.active ? 'var(--surface-3)' : 'transparent',
              color: n.active ? 'var(--ink)' : 'var(--ink-2)',
              borderRadius: 3, marginBottom: 1,
            }}>
              {n.expand && <span style={{ color: 'var(--ink-3)' }}>▾</span>}
              <span style={{ flex: 1, color: n.warn ? 'var(--warn)' : 'inherit' }}>{n.l}</span>
              <span style={{ color: 'var(--ink-3)', fontSize: 10 }}>{n.n}</span>
              {n.warn && <span style={{ color: 'var(--warn)' }}>!</span>}
            </div>
          ))}
        </div>
      </aside>

      {/* Editor split */}
      <main style={{ display: 'flex', flexDirection: 'column', minWidth: 0 }}>
        <div style={{ height: 38, borderBottom: '1px solid var(--line)', display: 'flex', alignItems: 'center', padding: '0 14px', gap: 4 }}>
          {[
            ['unidades[0].atividades', true],
            ['raw.json', false],
            ['diff', false],
          ].map(([l, on], i) => (
            <button key={i} className="btn-reset" style={{
              padding: '5px 12px', borderRadius: 4, fontSize: 11.5,
              background: on ? 'var(--surface-3)' : 'transparent',
              color: on ? 'var(--ink)' : 'var(--ink-3)',
              fontFamily: 'var(--mono)',
            }}>{l}</button>
          ))}
          <div style={{ flex: 1 }}/>
          <button className="btn-reset" style={{ padding: '4px 8px', fontSize: 11, color: 'var(--ink-3)', fontFamily: 'var(--mono)' }}>↶ undo</button>
          <button className="btn-reset" style={{ padding: '4px 8px', fontSize: 11, color: 'var(--ink-3)', fontFamily: 'var(--mono)' }}>↷ redo</button>
        </div>

        <div style={{ flex: 1, overflow: 'auto', padding: '14px 18px', fontFamily: 'var(--mono)', fontSize: 12, lineHeight: 1.65 }}>
          <div style={{ color: 'var(--ink-3)' }}>{'// unidades[0].atividades'}</div>
          <div>[</div>
          {[
            { type: 'forum', title: 'Apresentação da turma', ok: true },
            { type: 'wiki', title: 'Glossário OO', meta: '15 termos', ok: true },
            { type: 'quiz', title: 'Q1 — Classes e objetos', meta: '10 questões · 60min', linked: true },
            { type: 'tarefa', title: 'T1 — Modelagem de classes', meta: 'entrega DOCX', linked: true, edit: true },
          ].map((a, i) => (
            <div key={i} style={{
              margin: '4px 14px', padding: '10px 14px',
              background: a.edit ? 'var(--surface-2)' : 'var(--surface)',
              border: a.edit ? '1px solid var(--accent)' : '1px solid var(--line)',
              borderRadius: 5,
            }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                <span style={{ color: 'var(--ink-3)' }}>{'{'}</span>
                <span style={{ color: '#a78bfa' }}>"type"</span>
                <span style={{ color: 'var(--ink-3)' }}>:</span>
                <span style={{ color: '#4ade80' }}>"{a.type}"</span>
                <span style={{ color: 'var(--ink-3)' }}>,</span>
                <span style={{ color: '#a78bfa', marginLeft: 8 }}>"title"</span>
                <span style={{ color: 'var(--ink-3)' }}>:</span>
                <span style={{ color: '#4ade80', flex: 1 }}>"{a.title}"</span>
                {a.linked && <BBadge tone="accent">linked</BBadge>}
              </div>
              {a.meta && <div style={{ paddingLeft: 14, color: 'var(--ink-3)', fontSize: 10.5, marginTop: 2 }}>// {a.meta}</div>}
              {a.edit && (
                <div style={{ marginTop: 8, paddingTop: 8, borderTop: '1px solid var(--line)', display: 'flex', gap: 6 }}>
                  <input defaultValue="T1 — Modelagem de classes UML" style={{ flex: 1, background: 'var(--bg)', border: '1px solid var(--line-2)', borderRadius: 3, padding: '4px 8px', color: 'var(--ink)', fontSize: 11.5, fontFamily: 'var(--mono)', outline: 0 }}/>
                  <button className="btn-reset" style={{ padding: '4px 10px', fontSize: 11, background: 'var(--accent)', color: 'var(--bg)', borderRadius: 3 }}>save</button>
                </div>
              )}
            </div>
          ))}
          <div>]</div>
        </div>

        <div style={{ height: 36, borderTop: '1px solid var(--line)', display: 'flex', alignItems: 'center', padding: '0 14px', fontSize: 11, fontFamily: 'var(--mono)', color: 'var(--ink-3)', gap: 16 }}>
          <span>4 atividades · 0 erros · 1 aviso</span>
          <span style={{ marginLeft: 'auto' }}>schema: moodle 2.x ✓</span>
          <button className="btn-reset" style={{ padding: '4px 12px', borderRadius: 4, background: 'var(--accent)', color: 'var(--bg)', fontSize: 11.5, fontWeight: 500 }}>gerar .mbz →</button>
        </div>
      </main>

      {/* Right: collab + AI */}
      <aside style={{ borderLeft: '1px solid var(--line)', background: 'var(--surface)', display: 'flex', flexDirection: 'column' }}>
        <div style={{ padding: '14px 16px', borderBottom: '1px solid var(--line)' }}>
          <div style={{ fontSize: 10.5, fontFamily: 'var(--mono)', color: 'var(--ink-3)', textTransform: 'uppercase', letterSpacing: 0.5, marginBottom: 8 }}>Colaboração</div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 6, marginBottom: 10 }}>
            {['#f472b6', '#60a5fa', '#fbbf24'].map((c, i) => (
              <div key={i} style={{ width: 22, height: 22, borderRadius: '50%', background: `linear-gradient(135deg, ${c}, ${c}88)`, fontSize: 9, color: 'white', display: 'grid', placeItems: 'center', fontWeight: 600, marginLeft: i ? -6 : 0, border: '2px solid var(--surface)' }}>{['MR','AC','LS'][i]}</div>
            ))}
            <span style={{ fontSize: 11, color: 'var(--ink-3)', marginLeft: 4 }}>3 ativos</span>
          </div>
          <button className="btn-reset" style={{ width: '100%', padding: '7px 10px', border: '1px dashed var(--line-2)', borderRadius: 5, fontSize: 11.5, color: 'var(--ink-2)', fontFamily: 'var(--mono)' }}>
            🔗 copiar link de revisão
          </button>
        </div>

        <div style={{ padding: '14px 16px', borderBottom: '1px solid var(--line)' }}>
          <div style={{ fontSize: 10.5, fontFamily: 'var(--mono)', color: 'var(--ink-3)', textTransform: 'uppercase', letterSpacing: 0.5, marginBottom: 10 }}>Comentários</div>
          {[
            { who: 'MR', name: 'Marina', t: '2m', body: 'Mudei o título de T1 para incluir "UML". Confere?' },
            { who: 'LS', name: 'Lucas', t: '8m', body: 'A ementa parece truncada — precisa revisar manualmente.' },
          ].map((c, i) => (
            <div key={i} style={{ marginBottom: 12 }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 6, marginBottom: 4 }}>
                <div style={{ width: 18, height: 18, borderRadius: '50%', background: `linear-gradient(135deg, ${i ? '#fbbf24' : '#f472b6'}, ${i ? '#fbbf2488' : '#f472b688'})`, fontSize: 8, color: 'white', display: 'grid', placeItems: 'center', fontWeight: 600 }}>{c.who}</div>
                <span style={{ fontSize: 11.5, fontWeight: 500 }}>{c.name}</span>
                <span style={{ fontSize: 10.5, color: 'var(--ink-3)', fontFamily: 'var(--mono)' }}>{c.t}</span>
              </div>
              <div style={{ fontSize: 12, color: 'var(--ink-2)', lineHeight: 1.5, paddingLeft: 24 }}>{c.body}</div>
            </div>
          ))}
        </div>

        <div style={{ padding: '14px 16px', flex: 1 }}>
          <div style={{ fontSize: 10.5, fontFamily: 'var(--mono)', color: 'var(--accent)', textTransform: 'uppercase', letterSpacing: 0.5, marginBottom: 10, display: 'flex', alignItems: 'center', gap: 6 }}>
            <span style={{ width: 6, height: 6, borderRadius: '50%', background: 'var(--accent)' }}/>
            sugestão da IA
          </div>
          <div style={{ fontSize: 12.5, color: 'var(--ink-2)', lineHeight: 1.55, marginBottom: 10 }}>
            A Unidade 2 tem só 1 quiz para 25h de carga. Quer adicionar uma tarefa intermediária?
          </div>
          <div style={{ display: 'flex', gap: 6 }}>
            <button className="btn-reset" style={{ padding: '5px 10px', borderRadius: 4, background: 'var(--accent)', color: 'var(--bg)', fontSize: 11, fontWeight: 500 }}>aceitar</button>
            <button className="btn-reset" style={{ padding: '5px 10px', borderRadius: 4, fontSize: 11, color: 'var(--ink-2)' }}>dispensar</button>
          </div>
        </div>
      </aside>
    </div>
  </div>
);

/* ── B5 · Done ────────────────────────────────── */
const B_Done = () => (
  <div className="ab dir-b">
    <BNav active="new" />
    <main style={{ flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', padding: 40, position: 'relative', overflow: 'hidden' }}>
      {/* mesh-y bg */}
      <div style={{
        position: 'absolute', inset: 0,
        background: 'radial-gradient(circle at 30% 20%, rgba(129,140,248,0.15), transparent 40%), radial-gradient(circle at 70% 80%, rgba(167,139,250,0.12), transparent 40%)',
        pointerEvents: 'none',
      }}/>

      <div style={{ width: 680, position: 'relative', zIndex: 1 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 18 }}>
          <BBadge tone="ok">build #237 · ok</BBadge>
          <span style={{ fontFamily: 'var(--mono)', fontSize: 11, color: 'var(--ink-3)' }}>concluído em 28s</span>
        </div>
        <h1 style={{ fontSize: 38, margin: 0, fontWeight: 600, letterSpacing: -0.8, lineHeight: 1.05 }}>
          Build pronto.<br/>
          <span style={{ color: 'var(--ink-3)' }}>poo-2026.1.mbz</span>
        </h1>

        <div style={{ marginTop: 28, background: 'var(--surface)', border: '1px solid var(--line)', borderRadius: 8, overflow: 'hidden' }}>
          <div style={{ padding: '14px 18px', borderBottom: '1px solid var(--line)', display: 'flex', alignItems: 'center', gap: 14 }}>
            <div style={{ width: 36, height: 44, borderRadius: 4, background: 'linear-gradient(135deg, var(--accent), var(--accent-2))', color: 'white', fontSize: 9, fontWeight: 700, letterSpacing: 1, display: 'grid', placeItems: 'center' }}>MBZ</div>
            <div style={{ flex: 1 }}>
              <div style={{ fontSize: 13.5, fontWeight: 500 }}>poo-2026.1.mbz</div>
              <div style={{ fontFamily: 'var(--mono)', fontSize: 10.5, color: 'var(--ink-3)' }}>2.1 MB · sha1 a3f2…0c91 · moodle 2.x</div>
            </div>
            <button className="btn-reset" style={{ padding: '8px 18px', borderRadius: 5, background: 'var(--accent)', color: 'var(--bg)', fontSize: 12.5, fontWeight: 500 }}>↓ download</button>
          </div>
          <div style={{ padding: '12px 18px', display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 16 }}>
            {[['unidades', '3'], ['quizzes', '4'], ['tarefas', '3'], ['fóruns', '2']].map((s, i) => (
              <div key={i}>
                <div style={{ fontSize: 18, fontWeight: 600 }}>{s[1]}</div>
                <div style={{ fontFamily: 'var(--mono)', fontSize: 10, color: 'var(--ink-3)', textTransform: 'uppercase', letterSpacing: 0.5 }}>{s[0]}</div>
              </div>
            ))}
          </div>
        </div>

        <div style={{ marginTop: 16, display: 'flex', gap: 6, flexWrap: 'wrap' }}>
          <button className="btn-reset" style={{ padding: '6px 12px', borderRadius: 5, border: '1px solid var(--line-2)', background: 'var(--surface-2)', fontSize: 11.5, color: 'var(--ink-2)', fontFamily: 'var(--mono)' }}>↺ regenerate</button>
          <button className="btn-reset" style={{ padding: '6px 12px', borderRadius: 5, border: '1px solid var(--line-2)', background: 'var(--surface-2)', fontSize: 11.5, color: 'var(--ink-2)', fontFamily: 'var(--mono)' }}>📋 copy import-cmd</button>
          <button className="btn-reset" style={{ padding: '6px 12px', borderRadius: 5, border: '1px solid var(--line-2)', background: 'var(--surface-2)', fontSize: 11.5, color: 'var(--ink-2)', fontFamily: 'var(--mono)' }}>🔗 share</button>
          <button className="btn-reset" style={{ padding: '6px 12px', borderRadius: 5, fontSize: 11.5, color: 'var(--ink-3)', fontFamily: 'var(--mono)', marginLeft: 'auto' }}>+ nova disciplina</button>
        </div>
      </div>
    </main>
  </div>
);

window.B_Home = B_Home;
window.B_Settings = B_Settings;
window.B_Upload = B_Upload;
window.B_Review = B_Review;
window.B_Done = B_Done;
window.BNav = BNav;
window.BBadge = BBadge;
window.B_W = B_W;
window.B_H = B_H;

/* B v2 — Revisão em blocos + Home simplificada + Settings sem colab/faturamento */
const { BNav: BNavV2, BBadge: BBadgeV2 } = window;

/* ── Home v2 (uma tabela, 2 estados) ────────────── */
const B_HomeV2 = () => (
  <div className="ab dir-b">
    <BNavV2 active="home" />
    <div style={{ flex: 1, overflow: 'auto' }}>
      <div style={{ padding: '24px 32px 18px', borderBottom: '1px solid var(--line)' }}>
        <div style={{ fontSize: 11, color: 'var(--ink-3)', fontFamily: 'var(--mono)', marginBottom: 6, letterSpacing: 0.5 }}>WORKSPACE · LOCAL</div>
        <div style={{ display: 'flex', alignItems: 'flex-end', justifyContent: 'space-between', gap: 24 }}>
          <div>
            <h1 style={{ fontSize: 22, margin: 0, fontWeight: 600, letterSpacing: -0.4 }}>Disciplinas</h1>
            <p style={{ fontSize: 12.5, color: 'var(--ink-2)', marginTop: 4, marginBottom: 0 }}>Tudo salvo neste navegador. Limpar dados do site = perder tudo.</p>
          </div>
          <div style={{ display: 'flex', gap: 8 }}>
            <button className="btn-reset" style={{ padding: '7px 14px', borderRadius: 5, border: '1px solid var(--line-2)', background: 'var(--surface-2)', fontSize: 12.5, color: 'var(--ink)' }}>Builder manual</button>
            <button className="btn-reset" style={{ padding: '7px 14px', borderRadius: 5, background: 'var(--accent)', color: 'var(--bg)', fontSize: 12.5, fontWeight: 600 }}>+ Subir Matriz DE</button>
          </div>
        </div>
      </div>

      <div style={{ padding: '12px 32px', borderBottom: '1px solid var(--line)', display: 'flex', gap: 6, fontSize: 11.5, alignItems: 'center' }}>
        {[
          ['Todas', 7, true],
          ['Em construção', 3, false],
          ['Finalizadas', 4, false],
        ].map(([l, n, on], i) => (
          <button key={i} className="btn-reset" style={{
            padding: '5px 11px', borderRadius: 4,
            background: on ? 'var(--surface-3)' : 'transparent',
            color: on ? 'var(--ink)' : 'var(--ink-2)',
            border: on ? '1px solid var(--line-2)' : '1px solid transparent',
            display: 'flex', alignItems: 'center', gap: 6,
          }}>{l}<span style={{ fontFamily: 'var(--mono)', fontSize: 10, color: 'var(--ink-3)' }}>{n}</span></button>
        ))}
        <div style={{ flex: 1 }}/>
        <span style={{ fontFamily: 'var(--mono)', fontSize: 10.5, color: 'var(--ink-3)' }}>~3.4 MB usados · ordem: editado ↓</span>
      </div>

      <div style={{ padding: '14px 32px 28px' }}>
        <div style={{
          display: 'grid', gridTemplateColumns: '20px 2fr 1fr 90px 1fr 90px 100px',
          padding: '8px 14px', fontSize: 10, fontFamily: 'var(--mono)',
          color: 'var(--ink-3)', letterSpacing: 0.5, textTransform: 'uppercase',
        }}>
          <div></div><div>nome</div><div>código</div><div>carga</div><div>progresso</div><div>editado</div><div></div>
        </div>

        {[
          { name: 'Programação Orientada a Objetos', code: 'TADS-POO', h: '80h', state: 'building', progress: 80, edited: '18 min' },
          { name: 'Banco de Dados II', code: 'TADS-BDII', h: '60h', state: 'building', progress: 65, edited: '2 dias' },
          { name: 'Engenharia de Software', code: 'TADS-ES', h: '60h', state: 'building', progress: 45, edited: '12 dias' },
          { name: 'Redes de Computadores', code: 'TADS-REDES', h: '80h', state: 'done', size: '1.4 MB', edited: '3 dias' },
          { name: 'Sistemas Operacionais', code: 'TADS-SO', h: '60h', state: 'done', size: '1.1 MB', edited: '2 sem' },
          { name: 'Algoritmos e Estruturas de Dados', code: 'TADS-AED', h: '80h', state: 'done', size: '2.0 MB', edited: '1 mês' },
        ].map((r, i) => {
          const done = r.state === 'done';
          return (
            <div key={i} style={{
              display: 'grid', gridTemplateColumns: '20px 2fr 1fr 90px 1fr 90px 100px',
              padding: '11px 14px', borderTop: '1px solid var(--line)',
              fontSize: 12.5, alignItems: 'center', cursor: 'pointer',
            }}>
              <div style={{
                width: 8, height: 8, borderRadius: 1,
                background: done ? 'var(--ok)' : 'var(--accent)',
                opacity: done ? 1 : 0.7,
              }}/>
              <div style={{ color: 'var(--ink)', fontWeight: 500 }}>{r.name}</div>
              <div style={{ fontFamily: 'var(--mono)', fontSize: 11, color: 'var(--ink-3)' }}>{r.code}</div>
              <div style={{ fontFamily: 'var(--mono)', fontSize: 11, color: 'var(--ink-2)' }}>{r.h}</div>
              {done ? (
                <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                  <BBadgeV2 tone="ok">finalizada</BBadgeV2>
                  <span style={{ fontFamily: 'var(--mono)', fontSize: 10.5, color: 'var(--ink-3)' }}>{r.size}</span>
                </div>
              ) : (
                <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                  <div style={{ flex: 1, height: 3, background: 'var(--surface-3)', borderRadius: 2, overflow: 'hidden', maxWidth: 100 }}>
                    <div style={{ width: `${r.progress}%`, height: '100%', background: 'linear-gradient(90deg, var(--accent), var(--accent-2))' }}/>
                  </div>
                  <span style={{ fontFamily: 'var(--mono)', fontSize: 10.5, color: 'var(--ink-3)' }}>{r.progress}%</span>
                </div>
              )}
              <div style={{ fontSize: 11, color: 'var(--ink-3)' }}>{r.edited}</div>
              <div style={{ display: 'flex', gap: 6, justifyContent: 'flex-end', fontSize: 11 }}>
                {done ? (
                  <button className="btn-reset" style={{ color: 'var(--accent-ink)', fontFamily: 'var(--mono)' }}>↓ baixar .mbz</button>
                ) : (
                  <button className="btn-reset" style={{ color: 'var(--ink-2)', fontFamily: 'var(--mono)' }}>continuar →</button>
                )}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  </div>
);

/* ── Settings v2 (sem colab/faturamento) ────────── */
const B_SettingsV2 = () => (
  <div className="ab dir-b">
    <BNavV2 active="" />
    <div style={{ flex: 1, display: 'grid', gridTemplateColumns: '200px 1fr', overflow: 'hidden' }}>
      <aside style={{ borderRight: '1px solid var(--line)', padding: '20px 12px', background: 'var(--surface)' }}>
        <div style={{ fontSize: 10.5, fontFamily: 'var(--mono)', color: 'var(--ink-3)', textTransform: 'uppercase', letterSpacing: 0.5, padding: '6px 10px 8px' }}>Settings</div>
        {['Geral', 'Modelos de IA', 'Moodle', 'Atalhos', 'Dados locais'].map((s, i) => (
          <button key={i} className="btn-reset" style={{
            display: 'block', width: '100%', textAlign: 'left',
            padding: '6px 10px', borderRadius: 5, fontSize: 12.5,
            background: i === 1 ? 'var(--surface-3)' : 'transparent',
            color: i === 1 ? 'var(--ink)' : 'var(--ink-2)',
            fontWeight: i === 1 ? 500 : 400, marginBottom: 1,
          }}>{s}</button>
        ))}
      </aside>

      <main style={{ overflow: 'auto', padding: '28px 36px' }}>
        <h1 style={{ fontSize: 20, margin: 0, fontWeight: 600, letterSpacing: -0.3 }}>Modelos de IA</h1>
        <p style={{ fontSize: 13, color: 'var(--ink-2)', marginTop: 6, marginBottom: 24 }}>
          Configure provedores. Suas chaves ficam apenas neste navegador (localStorage).
        </p>

        <div style={{ background: 'var(--surface)', border: '1px solid var(--line)', borderRadius: 6, padding: '14px 16px', marginBottom: 18, display: 'flex', alignItems: 'center', gap: 12 }}>
          <span style={{ fontSize: 12, color: 'var(--ink-2)' }}>Modelo padrão para extração</span>
          <div style={{ flex: 1 }}/>
          <div style={{ display: 'flex', border: '1px solid var(--line)', borderRadius: 5, overflow: 'hidden' }}>
            {[['Gemini 2.5 Flash', true], ['GPT-4.1', false], ['Claude Sonnet 4.5', false]].map(([l, on], i) => (
              <button key={i} className="btn-reset" style={{
                padding: '6px 12px', fontSize: 11.5,
                background: on ? 'var(--surface-3)' : 'transparent',
                color: on ? 'var(--ink)' : 'var(--ink-3)',
                borderRight: i < 2 ? '1px solid var(--line)' : 'none',
                fontFamily: 'var(--mono)',
              }}>{l}</button>
            ))}
          </div>
        </div>

        <div style={{ background: 'var(--surface)', border: '1px solid var(--line)', borderRadius: 6, overflow: 'hidden' }}>
          {[
            { name: 'Google Gemini', model: 'gemini-2.5-flash', active: true, fallback: true, masked: 'AIza••••••••••••••a3F2', color: '#4285f4', letter: 'G' },
            { name: 'OpenAI', model: 'gpt-4.1 · gpt-4o', active: false, masked: '', color: '#10a37f', letter: 'O' },
            { name: 'Anthropic', model: 'claude-sonnet-4.5', active: false, masked: '', color: '#d97757', letter: 'A' },
          ].map((p, i) => (
            <div key={i} style={{ padding: '16px 18px', borderBottom: i < 2 ? '1px solid var(--line)' : 'none' }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 10 }}>
                <div style={{ width: 26, height: 26, borderRadius: 5, background: p.color, opacity: 0.85, display: 'grid', placeItems: 'center', color: 'white', fontSize: 11, fontWeight: 700 }}>{p.letter}</div>
                <div style={{ flex: 1 }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                    <span style={{ fontSize: 13, fontWeight: 500 }}>{p.name}</span>
                    {p.active && <BBadgeV2 tone="ok">conectado</BBadgeV2>}
                    {p.fallback && <BBadgeV2 tone="default">fallback servidor</BBadgeV2>}
                  </div>
                  <div style={{ fontFamily: 'var(--mono)', fontSize: 10.5, color: 'var(--ink-3)', marginTop: 2 }}>{p.model}</div>
                </div>
              </div>
              <div style={{ display: 'flex', alignItems: 'center', gap: 6, background: 'var(--surface-2)', border: '1px solid var(--line)', borderRadius: 4, padding: '6px 10px' }}>
                <span style={{ fontFamily: 'var(--mono)', fontSize: 10.5, color: 'var(--ink-3)' }}>API_KEY</span>
                <span style={{ width: 1, height: 12, background: 'var(--line)' }}/>
                <input
                  defaultValue={p.masked}
                  placeholder={p.active ? '' : 'cole sua chave para ativar'}
                  style={{ flex: 1, border: 0, outline: 0, background: 'transparent', fontFamily: 'var(--mono)', fontSize: 11.5, color: 'var(--ink)' }}
                />
                {p.active && <button className="btn-reset" style={{ fontSize: 10.5, color: 'var(--danger)', fontFamily: 'var(--mono)' }}>remover</button>}
              </div>
            </div>
          ))}
        </div>

        <div style={{ marginTop: 20, padding: '12px 14px', background: 'var(--surface)', border: '1px solid var(--line)', borderRadius: 5, fontSize: 11.5, color: 'var(--ink-2)', display: 'flex', gap: 10, alignItems: 'flex-start' }}>
          <span style={{ color: 'var(--accent)', fontFamily: 'var(--mono)' }}>ⓘ</span>
          <span>Sem chave própria, o app usa <span style={{ fontFamily: 'var(--mono)', fontSize: 11, color: 'var(--accent-ink)' }}>GEMINI_KEY</span> do servidor (limite mensal compartilhado).</span>
        </div>
      </main>
    </div>
  </div>
);

/* ── Review v2 — modo Blocos (default) ──────────── */
const B_ReviewBlocks = () => {
  const FilesPanel = () => (
    <div style={{ padding: '14px 16px', borderBottom: '1px solid var(--line)' }}>
      <div style={{ fontSize: 10.5, fontFamily: 'var(--mono)', color: 'var(--ink-3)', textTransform: 'uppercase', letterSpacing: 0.5, marginBottom: 10 }}>Arquivos do upload</div>
      {[
        { n: 'matriz-poo-2026.1.docx', s: '78 KB', kind: 'matriz' },
        { n: 'questoes-u1.docx', s: '42 KB', kind: 'quiz' },
        { n: 'questoes-u2.docx', s: '38 KB', kind: 'quiz' },
        { n: 'tarefas.docx', s: '24 KB', kind: 'tarefa' },
      ].map((f, i) => (
        <div key={i} style={{
          display: 'flex', alignItems: 'center', gap: 8,
          padding: '6px 8px', borderRadius: 4,
          marginBottom: 2,
          fontSize: 11.5, color: 'var(--ink-2)',
        }}>
          <div style={{ width: 14, height: 16, background: 'var(--surface-3)', borderRadius: 2, fontFamily: 'var(--mono)', fontSize: 6, color: 'var(--ink-3)', display: 'grid', placeItems: 'center', letterSpacing: 0.3, flexShrink: 0 }}>DOC</div>
          <span style={{ flex: 1, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap', fontFamily: 'var(--mono)', fontSize: 11 }}>{f.n}</span>
          <button className="btn-reset" style={{ fontSize: 10, color: 'var(--ink-3)', fontFamily: 'var(--mono)' }}>↗</button>
          <button className="btn-reset" style={{ fontSize: 10, color: 'var(--ink-3)', fontFamily: 'var(--mono)' }}>↓</button>
        </div>
      ))}
      <button className="btn-reset" style={{ marginTop: 6, width: '100%', padding: '6px 10px', border: '1px dashed var(--line-2)', borderRadius: 4, fontSize: 11, color: 'var(--ink-3)', fontFamily: 'var(--mono)' }}>+ adicionar arquivo</button>
    </div>
  );

  const AISugestion = () => (
    <div style={{ padding: '14px 16px', flex: 1 }}>
      <div style={{ fontSize: 10.5, fontFamily: 'var(--mono)', color: 'var(--accent)', textTransform: 'uppercase', letterSpacing: 0.5, marginBottom: 10, display: 'flex', alignItems: 'center', gap: 6 }}>
        <span style={{ width: 6, height: 6, borderRadius: '50%', background: 'var(--accent)' }}/>
        sugestão da IA
      </div>
      <div style={{ fontSize: 12.5, color: 'var(--ink-2)', lineHeight: 1.55, marginBottom: 10 }}>
        A Unidade 2 tem só 1 quiz para 25h. Quer adicionar uma tarefa intermediária?
      </div>
      <div style={{ display: 'flex', gap: 6, marginBottom: 16 }}>
        <button className="btn-reset" style={{ padding: '5px 10px', borderRadius: 4, background: 'var(--accent)', color: 'var(--bg)', fontSize: 11, fontWeight: 500 }}>aceitar</button>
        <button className="btn-reset" style={{ padding: '5px 10px', borderRadius: 4, fontSize: 11, color: 'var(--ink-2)' }}>dispensar</button>
      </div>
      <div style={{ paddingTop: 12, borderTop: '1px solid var(--line)' }}>
        <div style={{ fontSize: 10.5, fontFamily: 'var(--mono)', color: 'var(--ink-3)', textTransform: 'uppercase', letterSpacing: 0.5, marginBottom: 8 }}>Validação</div>
        <div style={{ fontFamily: 'var(--mono)', fontSize: 11, lineHeight: 1.7, color: 'var(--ink-2)' }}>
          <div><span style={{ color: 'var(--ok)' }}>✓</span> identificação · 6 campos</div>
          <div><span style={{ color: 'var(--warn)' }}>!</span> ementa: parece truncada</div>
          <div><span style={{ color: 'var(--ok)' }}>✓</span> 3 unidades · 13 atividades</div>
          <div><span style={{ color: 'var(--ok)' }}>✓</span> schema moodle 2.x</div>
        </div>
      </div>
    </div>
  );

  return (
    <div className="ab dir-b">
      <BNavV2 active="new" />
      <div style={{ flex: 1, display: 'grid', gridTemplateColumns: '260px 1fr 280px', overflow: 'hidden' }}>

        {/* Tree */}
        <aside style={{ borderRight: '1px solid var(--line)', overflow: 'auto', background: 'var(--surface)' }}>
          <div style={{ padding: '12px 14px', borderBottom: '1px solid var(--line)' }}>
            <div style={{ fontSize: 13, fontWeight: 600, marginBottom: 2 }}>Programação OO</div>
            <div style={{ fontFamily: 'var(--mono)', fontSize: 10.5, color: 'var(--ink-3)' }}>TADS-POO · 80h</div>
          </div>
          <div style={{ padding: 8 }}>
            {[
              { l: 'Identificação', n: 6, ok: true, depth: 0 },
              { l: 'Ementa', n: 1, warn: true, depth: 0 },
              { l: 'Objetivos', n: 8, ok: true, depth: 0 },
              { l: '▾ Unidade 1 — Conceitos', n: 4, depth: 0, active: true },
              { l: 'Fórum: Apresentação', depth: 1 },
              { l: 'Wiki: Glossário OO', depth: 1 },
              { l: 'Quiz: Q1', depth: 1, sel: true },
              { l: 'Tarefa: T1', depth: 1, edit: true },
              { l: '▸ Unidade 2 — Herança', n: 5, depth: 0 },
              { l: '▸ Unidade 3 — Polimorfismo', n: 4, depth: 0 },
              { l: 'Avaliações', n: 3, depth: 0 },
            ].map((n, i) => (
              <div key={i} style={{
                padding: '5px 10px', paddingLeft: 10 + n.depth * 14,
                display: 'flex', alignItems: 'center', gap: 6,
                background: n.sel ? 'var(--surface-3)' : 'transparent',
                color: n.active ? 'var(--ink)' : 'var(--ink-2)',
                fontWeight: n.active ? 500 : 400,
                borderRadius: 4, fontSize: 12.5, marginBottom: 1,
              }}>
                <span style={{ flex: 1, color: n.warn ? 'var(--warn)' : (n.edit ? 'var(--accent-ink)' : 'inherit') }}>
                  {n.l}{n.edit && ' ✎'}
                </span>
                {n.n != null && <span style={{ color: 'var(--ink-3)', fontSize: 10, fontFamily: 'var(--mono)' }}>{n.n}</span>}
                {n.warn && <span style={{ color: 'var(--warn)' }}>!</span>}
              </div>
            ))}
          </div>
        </aside>

        {/* Main editor — BLOCKS view */}
        <main style={{ display: 'flex', flexDirection: 'column', minWidth: 0 }}>
          {/* View toggle */}
          <div style={{ height: 38, borderBottom: '1px solid var(--line)', display: 'flex', alignItems: 'center', padding: '0 14px', gap: 0 }}>
            <div style={{ display: 'flex', border: '1px solid var(--line)', borderRadius: 5, overflow: 'hidden', marginRight: 12 }}>
              {[
                ['◧ Blocos', true],
                ['{ } JSON', false],
                ['◐ Diff', false],
              ].map(([l, on], i) => (
                <button key={i} className="btn-reset" style={{
                  padding: '5px 12px', fontSize: 11.5,
                  background: on ? 'var(--surface-3)' : 'transparent',
                  color: on ? 'var(--ink)' : 'var(--ink-3)',
                  borderRight: i < 2 ? '1px solid var(--line)' : 'none',
                  fontFamily: 'var(--mono)',
                  fontWeight: on ? 500 : 400,
                }}>{l}</button>
              ))}
            </div>
            <span style={{ fontFamily: 'var(--mono)', fontSize: 11, color: 'var(--ink-3)' }}>unidade 1 · 4 atividades</span>
            <div style={{ flex: 1 }}/>
            <button className="btn-reset" style={{ padding: '4px 8px', fontSize: 11, color: 'var(--ink-3)', fontFamily: 'var(--mono)' }}>↶</button>
            <button className="btn-reset" style={{ padding: '4px 8px', fontSize: 11, color: 'var(--ink-3)', fontFamily: 'var(--mono)' }}>↷</button>
            <button className="btn-reset" style={{ padding: '4px 10px', fontSize: 11, color: 'var(--ink-2)', fontFamily: 'var(--mono)' }}>auto-salvo · há 2s</button>
          </div>

          {/* BLOCKS */}
          <div style={{ flex: 1, overflow: 'auto', padding: '20px 24px', background: 'var(--bg)' }}>
            {/* Identification block */}
            <BlockCard
              kind="ident"
              title="Identificação"
              meta="6 campos · da Matriz DE"
              ok
            >
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 10 }}>
                {[
                  ['Nome', 'Programação Orientada a Objetos'],
                  ['Código', 'TADS-POO'],
                  ['Carga horária', '80h'],
                  ['Período', '2026.1'],
                  ['Curso', 'TADS'],
                  ['Pré-requisitos', 'Algoritmos I'],
                ].map(([l, v], i) => (
                  <div key={i}>
                    <div style={{ fontSize: 10, fontFamily: 'var(--mono)', color: 'var(--ink-3)', textTransform: 'uppercase', letterSpacing: 0.5, marginBottom: 3 }}>{l}</div>
                    <div style={{ fontSize: 12.5, color: 'var(--ink)' }}>{v}</div>
                  </div>
                ))}
              </div>
            </BlockCard>

            {/* Ementa block — warning */}
            <BlockCard
              kind="ementa"
              title="Ementa"
              meta="texto da Matriz · parece truncado"
              warn
            >
              <div style={{ fontSize: 12.5, color: 'var(--ink-2)', lineHeight: 1.6 }}>
                Conceitos de orientação a objetos. Classes, objetos, atributos, métodos.
                Encapsulamento, herança e polimorfismo. Aplicações em Python e Java…
                <span style={{ color: 'var(--warn)', fontFamily: 'var(--mono)', fontSize: 11 }}> [truncado]</span>
              </div>
            </BlockCard>

            {/* Unidade block — expanded with activities */}
            <BlockCard
              kind="unidade"
              title="Unidade 1 — Conceitos"
              meta="4 atividades · 25h"
              expanded
            >
              <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
                {[
                  { type: 'forum', title: 'Apresentação da turma', meta: 'aberta · 1ª semana' },
                  { type: 'wiki', title: 'Glossário OO', meta: '15 termos · colaborativa' },
                  { type: 'quiz', title: 'Q1 — Classes e objetos', meta: '10 questões · 60min · 2 tentativas', sel: true },
                  { type: 'tarefa', title: 'T1 — Modelagem de classes UML', meta: 'entrega DOCX · 14 dias', edit: true },
                ].map((a, i) => {
                  const tones = {
                    forum: ['#60a5fa', '🗨'],
                    wiki: ['#a78bfa', '☞'],
                    quiz: ['#fbbf24', '?'],
                    tarefa: ['#4ade80', '✎'],
                  };
                  const [color, ico] = tones[a.type];
                  return (
                    <div key={i} style={{
                      display: 'flex', alignItems: 'center', gap: 12,
                      padding: '10px 12px', borderRadius: 5,
                      background: a.sel ? 'var(--surface-3)' : 'var(--surface)',
                      border: `1px solid ${a.sel ? 'var(--accent)' : 'var(--line)'}`,
                    }}>
                      <div style={{ width: 26, height: 26, borderRadius: 5, background: `${color}22`, color, display: 'grid', placeItems: 'center', fontSize: 13, flexShrink: 0 }}>{ico}</div>
                      <div style={{ flex: 1, minWidth: 0 }}>
                        <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                          <BBadgeV2 tone="default">{a.type}</BBadgeV2>
                          <span style={{ fontSize: 12.5, fontWeight: 500, color: 'var(--ink)' }}>{a.title}</span>
                          {a.edit && <BBadgeV2 tone="accent">editado</BBadgeV2>}
                        </div>
                        <div style={{ fontSize: 11, color: 'var(--ink-3)', fontFamily: 'var(--mono)', marginTop: 2 }}>{a.meta}</div>
                      </div>
                      <button className="btn-reset" style={{ color: 'var(--ink-3)', fontSize: 11, fontFamily: 'var(--mono)' }}>editar</button>
                      <button className="btn-reset" style={{ color: 'var(--ink-3)', fontSize: 14 }}>⋯</button>
                    </div>
                  );
                })}
                <button className="btn-reset" style={{ padding: '8px 12px', textAlign: 'left', border: '1px dashed var(--line-2)', borderRadius: 5, color: 'var(--ink-3)', fontSize: 12, fontFamily: 'var(--mono)' }}>+ adicionar atividade</button>
              </div>
            </BlockCard>

            {/* Unidade 2 — collapsed */}
            <BlockCard
              kind="unidade"
              title="Unidade 2 — Herança"
              meta="5 atividades · 25h"
              collapsed
            />

            {/* Unidade 3 — collapsed */}
            <BlockCard
              kind="unidade"
              title="Unidade 3 — Polimorfismo"
              meta="4 atividades · 30h"
              collapsed
            />
          </div>

          {/* Footer */}
          <div style={{ height: 40, borderTop: '1px solid var(--line)', display: 'flex', alignItems: 'center', padding: '0 14px', fontSize: 11, fontFamily: 'var(--mono)', color: 'var(--ink-3)', gap: 16 }}>
            <span>13 atividades · 0 erros · 1 aviso</span>
            <span style={{ marginLeft: 'auto' }}>schema: moodle 2.x ✓</span>
            <button className="btn-reset" style={{ padding: '5px 14px', borderRadius: 4, background: 'var(--accent)', color: 'var(--bg)', fontSize: 11.5, fontWeight: 600 }}>finalizar e gerar .mbz →</button>
          </div>
        </main>

        {/* Right: arquivos + IA */}
        <aside style={{ borderLeft: '1px solid var(--line)', background: 'var(--surface)', display: 'flex', flexDirection: 'column' }}>
          <FilesPanel />
          <AISugestion />
        </aside>
      </div>
    </div>
  );
};

/* Helper: BlockCard */
const BlockCard = ({ kind, title, meta, ok, warn, expanded, collapsed, children }) => {
  const stripe = warn ? 'var(--warn)' : (ok ? 'var(--ok)' : 'var(--accent)');
  return (
    <section style={{
      background: 'var(--surface)',
      border: '1px solid var(--line)',
      borderRadius: 7,
      marginBottom: 12,
      overflow: 'hidden',
      position: 'relative',
    }}>
      <div style={{ position: 'absolute', left: 0, top: 0, bottom: 0, width: 2, background: stripe, opacity: 0.6 }}/>
      <header style={{
        display: 'flex', alignItems: 'center', gap: 10,
        padding: '12px 16px',
        borderBottom: collapsed ? 'none' : '1px solid var(--line)',
      }}>
        <span style={{ fontSize: 11, color: 'var(--ink-3)', fontFamily: 'var(--mono)' }}>{collapsed ? '▸' : '▾'}</span>
        <span style={{ fontSize: 13.5, fontWeight: 600, letterSpacing: -0.2 }}>{title}</span>
        {warn && <BBadgeV2 tone="warn">aviso</BBadgeV2>}
        <div style={{ flex: 1 }}/>
        <span style={{ fontSize: 11, fontFamily: 'var(--mono)', color: 'var(--ink-3)' }}>{meta}</span>
        <button className="btn-reset" style={{ color: 'var(--ink-3)', fontSize: 14, marginLeft: 6 }}>⋯</button>
      </header>
      {!collapsed && children && (
        <div style={{ padding: '14px 16px' }}>{children}</div>
      )}
    </section>
  );
};

window.B_HomeV2 = B_HomeV2;
window.B_SettingsV2 = B_SettingsV2;
window.B_ReviewBlocks = B_ReviewBlocks;

/* B Home (direta) — substitui landing + onboarding + empty state */
const { BNav: BNav2, BBadge: BBadge2 } = window;

const B_HomeDirect = () => (
  <div className="ab dir-b">
    <BNav2 active="home" />

    <div style={{ flex: 1, overflow: 'auto' }}>
      {/* Header — ação dominante: começar uma disciplina */}
      <div style={{ padding: '28px 32px 24px', borderBottom: '1px solid var(--line)' }}>
        <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', gap: 24, marginBottom: 18 }}>
          <div>
            <div style={{ fontSize: 11, color: 'var(--ink-3)', fontFamily: 'var(--mono)', marginBottom: 6, letterSpacing: 0.5 }}>WORKSPACE</div>
            <h1 style={{ fontSize: 24, margin: 0, fontWeight: 600, letterSpacing: -0.5 }}>Course Gen</h1>
            <p style={{ fontSize: 13, color: 'var(--ink-2)', marginTop: 4, marginBottom: 0 }}>Da Matriz DE ao pacote Moodle.</p>
          </div>
          <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
            <span style={{ fontFamily: 'var(--mono)', fontSize: 10.5, color: 'var(--ink-3)' }}>gemini-2.5-flash · ok</span>
          </div>
        </div>

        {/* Dois caminhos lado a lado, primários */}
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
          <button className="btn-reset" style={{
            background: 'var(--surface)', border: '1px solid var(--accent)',
            borderRadius: 8, padding: '18px 20px', textAlign: 'left',
            display: 'flex', alignItems: 'center', gap: 14,
            boxShadow: '0 0 0 4px rgba(129,140,248,0.08)',
          }}>
            <div style={{ width: 36, height: 36, borderRadius: 7, background: 'var(--accent-soft)', color: 'var(--accent)', display: 'grid', placeItems: 'center', fontSize: 18 }}>↑</div>
            <div style={{ flex: 1 }}>
              <div style={{ fontSize: 14, fontWeight: 600, marginBottom: 2 }}>Subir Matriz DE</div>
              <div style={{ fontSize: 12, color: 'var(--ink-2)' }}>Anexe a Matriz, quizzes e tarefas. A IA estrutura.</div>
            </div>
            <span style={{ color: 'var(--accent)', fontSize: 14 }}>→</span>
          </button>
          <button className="btn-reset" style={{
            background: 'var(--surface)', border: '1px solid var(--line-2)',
            borderRadius: 8, padding: '18px 20px', textAlign: 'left',
            display: 'flex', alignItems: 'center', gap: 14,
          }}>
            <div style={{ width: 36, height: 36, borderRadius: 7, background: 'var(--surface-2)', color: 'var(--ink-2)', display: 'grid', placeItems: 'center', fontSize: 18 }}>◐</div>
            <div style={{ flex: 1 }}>
              <div style={{ fontSize: 14, fontWeight: 600, marginBottom: 2 }}>Builder manual</div>
              <div style={{ fontSize: 12, color: 'var(--ink-2)' }}>Monte unidades e atividades sem documentos.</div>
            </div>
            <span style={{ color: 'var(--ink-3)', fontSize: 14 }}>→</span>
          </button>
        </div>
      </div>

      {/* Em construção (rascunhos) */}
      <div style={{ padding: '22px 32px 14px' }}>
        <div style={{ display: 'flex', alignItems: 'baseline', gap: 10, marginBottom: 14 }}>
          <h2 style={{ fontSize: 13, fontWeight: 600, margin: 0, letterSpacing: -0.2 }}>Em construção</h2>
          <BBadge2 tone="default">3</BBadge2>
          <span style={{ fontSize: 11.5, color: 'var(--ink-3)' }}>continue de onde parou</span>
          <div style={{ flex: 1 }}/>
          <button className="btn-reset" style={{ fontSize: 11, color: 'var(--ink-2)', fontFamily: 'var(--mono)' }}>limpar antigos</button>
        </div>

        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 10 }}>
          {[
            { name: 'Programação OO', code: 'TADS-POO', progress: 80, stage: 'revisão', edited: '18 min', expired: false, files: 3 },
            { name: 'Banco de Dados II', code: 'TADS-BDII', progress: 65, stage: 'revisão', edited: '2 dias', expired: false, files: 2 },
            { name: 'Engenharia de SW', code: 'TADS-ES', progress: 45, stage: 'arquivos expirados', edited: '12 dias', expired: true, files: 2 },
          ].map((d, i) => (
            <button key={i} className="btn-reset" style={{
              background: 'var(--surface)',
              border: `1px solid ${d.expired ? 'rgba(251,191,36,0.3)' : 'var(--line)'}`,
              borderRadius: 6, padding: '12px 14px', textAlign: 'left',
              display: 'flex', flexDirection: 'column', gap: 8,
            }}>
              <div style={{ display: 'flex', alignItems: 'flex-start', gap: 8 }}>
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div style={{ fontSize: 13, fontWeight: 600, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{d.name}</div>
                  <div style={{ fontFamily: 'var(--mono)', fontSize: 10, color: 'var(--ink-3)', marginTop: 2 }}>{d.code} · {d.files} anexos</div>
                </div>
                <BBadge2 tone={d.expired ? 'warn' : 'accent'}>{d.stage}</BBadge2>
              </div>
              <div style={{ height: 3, background: 'var(--surface-3)', borderRadius: 2, overflow: 'hidden' }}>
                <div style={{ width: `${d.progress}%`, height: '100%', background: d.expired ? 'var(--warn)' : 'linear-gradient(90deg, var(--accent), var(--accent-2))' }}/>
              </div>
              <div style={{ display: 'flex', justifyContent: 'space-between', fontFamily: 'var(--mono)', fontSize: 10, color: 'var(--ink-3)' }}>
                <span>{d.progress}%</span>
                <span>{d.edited}</span>
              </div>
            </button>
          ))}
        </div>
      </div>

      {/* Pacotes prontos (.mbz) */}
      <div style={{ padding: '18px 32px 28px' }}>
        <div style={{ display: 'flex', alignItems: 'baseline', gap: 10, marginBottom: 14 }}>
          <h2 style={{ fontSize: 13, fontWeight: 600, margin: 0, letterSpacing: -0.2 }}>Pacotes prontos</h2>
          <BBadge2 tone="default">5</BBadge2>
          <span style={{ fontSize: 11.5, color: 'var(--ink-3)' }}>baixe novamente quando precisar</span>
          <div style={{ flex: 1 }}/>
          <span style={{ fontFamily: 'var(--mono)', fontSize: 10.5, color: 'var(--ink-3)' }}>ordem: recente ↓</span>
        </div>

        <div style={{ background: 'var(--surface)', border: '1px solid var(--line)', borderRadius: 6, overflow: 'hidden' }}>
          <div style={{
            display: 'grid', gridTemplateColumns: '24px 2fr 1fr 90px 100px 90px',
            padding: '8px 14px', borderBottom: '1px solid var(--line)',
            fontSize: 10, fontFamily: 'var(--mono)', color: 'var(--ink-3)',
            letterSpacing: 0.5, textTransform: 'uppercase',
          }}>
            <div></div><div>nome</div><div>código</div><div>tamanho</div><div>gerado</div><div></div>
          </div>
          {[
            ['Programação Orientada a Objetos', 'TADS-POO', '2.1 MB', '2h'],
            ['Redes de Computadores', 'TADS-REDES', '1.4 MB', '3 dias'],
            ['Engenharia de Software', 'TADS-ES', '1.8 MB', '1 sem'],
            ['Sistemas Operacionais', 'TADS-SO', '1.1 MB', '2 sem'],
          ].map((r, i) => (
            <div key={i} style={{
              display: 'grid', gridTemplateColumns: '24px 2fr 1fr 90px 100px 90px',
              padding: '11px 14px', borderBottom: i < 3 ? '1px solid var(--line)' : 'none',
              fontSize: 12.5, alignItems: 'center', cursor: 'pointer',
            }}>
              <div style={{ width: 14, height: 16, background: 'var(--surface-3)', borderRadius: 2, fontFamily: 'var(--mono)', fontSize: 6.5, color: 'var(--ink-3)', display: 'grid', placeItems: 'center', letterSpacing: 0.3 }}>MBZ</div>
              <div style={{ color: 'var(--ink)', fontWeight: 500 }}>{r[0]}</div>
              <div style={{ fontFamily: 'var(--mono)', fontSize: 11, color: 'var(--ink-3)' }}>{r[1]}</div>
              <div style={{ fontFamily: 'var(--mono)', fontSize: 11, color: 'var(--ink-2)' }}>{r[2]}</div>
              <div style={{ fontSize: 11, color: 'var(--ink-3)' }}>{r[3]}</div>
              <div style={{ display: 'flex', gap: 6, justifyContent: 'flex-end' }}>
                <button className="btn-reset" style={{ fontSize: 11, color: 'var(--accent-ink)', fontFamily: 'var(--mono)' }}>↓ baixar</button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  </div>
);

window.B_HomeDirect = B_HomeDirect;

/* B Intro screens — landing, onboarding, empty states, error/loading */
const { BNav, BBadge } = window;

/* ── B8 · Landing (não logado) ─────────────────── */
const B_Landing = () => (
  <div className="ab dir-b" style={{ overflow: 'auto' }}>
    {/* Top bar */}
    <nav style={{
      height: 60, display: 'flex', alignItems: 'center', padding: '0 40px',
      borderBottom: '1px solid var(--line)', flexShrink: 0,
    }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
        <div style={{ width: 22, height: 22, borderRadius: 5, background: 'linear-gradient(135deg, var(--accent), var(--accent-2))', position: 'relative' }}>
          <div style={{ position: 'absolute', inset: 5, background: 'var(--bg)', borderRadius: 2 }}/>
        </div>
        <span style={{ fontSize: 14, fontWeight: 600, letterSpacing: -0.2 }}>CourseGen<span style={{ color: 'var(--accent)' }}>·</span>AI</span>
      </div>
      <div style={{ flex: 1 }}/>
      <div style={{ display: 'flex', gap: 4, fontSize: 12.5 }}>
        {['Como funciona', 'Modelos', 'Documentação', 'GitHub ↗'].map((l, i) => (
          <button key={i} className="btn-reset" style={{ padding: '6px 12px', borderRadius: 5, color: 'var(--ink-2)' }}>{l}</button>
        ))}
      </div>
      <button className="btn-reset" style={{ marginLeft: 16, padding: '6px 14px', borderRadius: 5, background: 'var(--ink)', color: 'var(--bg)', fontSize: 12.5, fontWeight: 500 }}>Entrar →</button>
    </nav>

    {/* Hero */}
    <section style={{ padding: '72px 40px 56px', position: 'relative', borderBottom: '1px solid var(--line)' }}>
      <div style={{ position: 'absolute', inset: 0, background: 'radial-gradient(circle at 20% 30%, rgba(129,140,248,0.12), transparent 50%), radial-gradient(circle at 80% 70%, rgba(167,139,250,0.08), transparent 50%)', pointerEvents: 'none' }}/>
      <div style={{ maxWidth: 880, position: 'relative' }}>
        <BBadge tone="accent">v0.4 · early access</BBadge>
        <h1 style={{ fontSize: 56, lineHeight: 1.0, letterSpacing: -1.4, margin: '20px 0 18px', fontWeight: 600 }}>
          Da Matriz DE ao <span style={{ background: 'linear-gradient(135deg, var(--accent), var(--accent-2))', WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent' }}>pacote Moodle</span><br/>em 30 segundos.
        </h1>
        <p style={{ fontSize: 17, color: 'var(--ink-2)', lineHeight: 1.55, maxWidth: 620, margin: '0 0 30px' }}>
          Pare de cadastrar disciplinas no Moodle uma a uma. Suba a Matriz, deixa a IA estruturar e baixe o <span style={{ fontFamily: 'var(--mono)', fontSize: 14 }}>.mbz</span> pronto para importar.
        </p>
        <div style={{ display: 'flex', gap: 10, alignItems: 'center' }}>
          <button className="btn-reset" style={{ padding: '11px 22px', borderRadius: 6, background: 'var(--accent)', color: 'var(--bg)', fontSize: 13.5, fontWeight: 600 }}>Experimentar grátis</button>
          <button className="btn-reset" style={{ padding: '11px 22px', borderRadius: 6, border: '1px solid var(--line-2)', background: 'var(--surface-2)', fontSize: 13.5, color: 'var(--ink)' }}>Ver demo (2 min)</button>
          <span style={{ fontFamily: 'var(--mono)', fontSize: 11, color: 'var(--ink-3)', marginLeft: 10 }}>sem cartão · usa sua chave Gemini</span>
        </div>
      </div>
    </section>

    {/* How it works */}
    <section style={{ padding: '48px 40px', borderBottom: '1px solid var(--line)' }}>
      <div style={{ fontSize: 11, fontFamily: 'var(--mono)', color: 'var(--ink-3)', textTransform: 'uppercase', letterSpacing: 1, marginBottom: 20 }}>Como funciona</div>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 16 }}>
        {[
          { n: '01', t: 'Anexe', body: 'Matriz DE (.docx) + quizzes e tarefas opcionais.', tag: 'upload' },
          { n: '02', t: 'Revise', body: 'A IA extrai estrutura. Você ajusta o JSON antes de gerar.', tag: 'review' },
          { n: '03', t: 'Importe', body: 'Pacote .mbz pronto para o Moodle 2.x. Um clique.', tag: 'export' },
        ].map((s, i) => (
          <div key={i} style={{ background: 'var(--surface)', border: '1px solid var(--line)', borderRadius: 8, padding: '20px 22px', position: 'relative' }}>
            <div style={{ fontFamily: 'var(--mono)', fontSize: 24, color: 'var(--accent)', marginBottom: 12, letterSpacing: -1 }}>{s.n}</div>
            <div style={{ fontSize: 16, fontWeight: 600, marginBottom: 6 }}>{s.t}</div>
            <div style={{ fontSize: 13, color: 'var(--ink-2)', lineHeight: 1.55, marginBottom: 14 }}>{s.body}</div>
            <BBadge>{s.tag}</BBadge>
          </div>
        ))}
      </div>
    </section>

    {/* Features grid */}
    <section style={{ padding: '48px 40px' }}>
      <div style={{ fontSize: 11, fontFamily: 'var(--mono)', color: 'var(--ink-3)', textTransform: 'uppercase', letterSpacing: 1, marginBottom: 20 }}>Recursos</div>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 12 }}>
        {[
          ['Multi-modelo', 'Gemini, OpenAI ou Claude — você escolhe.'],
          ['Builder manual', 'Monte do zero quando não houver Matriz.'],
          ['Colaboração', 'Compartilhe link de revisão com o time.'],
          ['Privado', 'Suas chaves nunca passam pelo servidor.'],
        ].map(([t, b], i) => (
          <div key={i} style={{ padding: '16px 18px', border: '1px solid var(--line)', borderRadius: 6, background: 'var(--surface)' }}>
            <div style={{ fontSize: 13, fontWeight: 600, marginBottom: 4 }}>{t}</div>
            <div style={{ fontSize: 12, color: 'var(--ink-2)', lineHeight: 1.5 }}>{b}</div>
          </div>
        ))}
      </div>
    </section>
  </div>
);

/* ── B9 · Onboarding (primeira visita, sem .env) ── */
const B_Onboarding = () => (
  <div className="ab dir-b" style={{ alignItems: 'center', justifyContent: 'center' }}>
    <div style={{ position: 'absolute', inset: 0, background: 'radial-gradient(circle at 50% 30%, rgba(129,140,248,0.12), transparent 50%)', pointerEvents: 'none' }}/>
    <div style={{ width: 560, position: 'relative' }}>
      {/* Stepper */}
      <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 28, fontFamily: 'var(--mono)', fontSize: 11, color: 'var(--ink-3)', textTransform: 'uppercase' }}>
        <span style={{ display: 'flex', alignItems: 'center', gap: 6, color: 'var(--ink)' }}>
          <span style={{ width: 14, height: 14, borderRadius: '50%', background: 'var(--accent)', color: 'var(--bg)', display: 'grid', placeItems: 'center', fontSize: 9, fontWeight: 700 }}>1</span>
          chave de IA
        </span>
        <span>—</span>
        <span style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
          <span style={{ width: 14, height: 14, borderRadius: '50%', border: '1px solid var(--line-2)', display: 'grid', placeItems: 'center', fontSize: 9 }}>2</span>
          perfil
        </span>
        <span>—</span>
        <span style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
          <span style={{ width: 14, height: 14, borderRadius: '50%', border: '1px solid var(--line-2)', display: 'grid', placeItems: 'center', fontSize: 9 }}>3</span>
          começar
        </span>
      </div>

      <BBadge tone="warn">nenhuma chave detectada no .env</BBadge>
      <h1 style={{ fontSize: 32, fontWeight: 600, letterSpacing: -0.6, margin: '14px 0 10px', lineHeight: 1.1 }}>
        Conecte um modelo<br/>para começar.
      </h1>
      <p style={{ fontSize: 14, color: 'var(--ink-2)', lineHeight: 1.6, marginTop: 0, marginBottom: 26 }}>
        Cole sua chave do Google Gemini abaixo. Ela fica apenas neste navegador (localStorage) — nunca chega ao nosso servidor.
        Você pode adicionar OpenAI e Claude depois nas Configurações.
      </p>

      <div style={{ background: 'var(--surface)', border: '1px solid var(--line)', borderRadius: 8, padding: '18px 20px', marginBottom: 14 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 12 }}>
          <div style={{ width: 26, height: 26, borderRadius: 5, background: '#4285f4', color: 'white', fontSize: 11, fontWeight: 700, display: 'grid', placeItems: 'center' }}>G</div>
          <div style={{ flex: 1 }}>
            <div style={{ fontSize: 13, fontWeight: 500 }}>Google Gemini</div>
            <div style={{ fontFamily: 'var(--mono)', fontSize: 10.5, color: 'var(--ink-3)' }}>gemini-2.5-flash · recomendado</div>
          </div>
          <button className="btn-reset" style={{ fontSize: 11, color: 'var(--accent)', fontFamily: 'var(--mono)' }}>obter chave ↗</button>
        </div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 6, background: 'var(--surface-2)', border: '1px solid var(--line)', borderRadius: 5, padding: '8px 12px' }}>
          <span style={{ fontFamily: 'var(--mono)', fontSize: 10.5, color: 'var(--ink-3)' }}>API_KEY</span>
          <span style={{ width: 1, height: 14, background: 'var(--line)' }}/>
          <input placeholder="AIza..." style={{ flex: 1, border: 0, outline: 0, background: 'transparent', fontFamily: 'var(--mono)', fontSize: 12.5, color: 'var(--ink)' }}/>
        </div>
        <div style={{ display: 'flex', gap: 8, marginTop: 12, alignItems: 'center' }}>
          <button className="btn-reset" style={{ padding: '8px 16px', borderRadius: 5, background: 'var(--accent)', color: 'var(--bg)', fontSize: 12.5, fontWeight: 600 }}>Conectar</button>
          <button className="btn-reset" style={{ padding: '8px 14px', borderRadius: 5, fontSize: 12.5, color: 'var(--ink-2)' }}>Pular por agora</button>
          <div style={{ flex: 1 }}/>
          <span style={{ fontFamily: 'var(--mono)', fontSize: 10.5, color: 'var(--ink-3)' }}>↵ enter</span>
        </div>
      </div>

      <div style={{ fontSize: 11.5, color: 'var(--ink-3)', display: 'flex', alignItems: 'center', gap: 6, fontFamily: 'var(--mono)' }}>
        🔒 chave criptografada no localStorage · revogável a qualquer momento
      </div>
    </div>
  </div>
);

/* ── B10 · Empty state — Home sem disciplinas ───── */
const B_EmptyHome = () => (
  <div className="ab dir-b">
    <BNav active="home" />
    <div style={{ flex: 1, display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 40, position: 'relative' }}>
      <div style={{ position: 'absolute', inset: 0, background: 'radial-gradient(circle at 50% 40%, rgba(129,140,248,0.06), transparent 60%)', pointerEvents: 'none' }}/>
      <div style={{ maxWidth: 720, width: '100%', position: 'relative', textAlign: 'center' }}>
        <div style={{
          width: 64, height: 64, margin: '0 auto 22px',
          borderRadius: 12, background: 'var(--surface)',
          border: '1px dashed var(--line-2)',
          display: 'grid', placeItems: 'center',
          fontSize: 28, color: 'var(--ink-3)',
        }}>＋</div>
        <h1 style={{ fontSize: 26, fontWeight: 600, letterSpacing: -0.5, margin: '0 0 8px' }}>Nenhuma disciplina ainda</h1>
        <p style={{ fontSize: 14, color: 'var(--ink-2)', lineHeight: 1.6, margin: '0 auto 28px', maxWidth: 480 }}>
          Você pode partir de uma Matriz DE existente ou montar a disciplina do zero pelo Builder.
        </p>

        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12, textAlign: 'left' }}>
          {[
            {
              icon: '↑',
              t: 'Subir Matriz DE',
              body: 'Anexe a Matriz da disciplina, quizzes e tarefas. A IA estrutura tudo.',
              cta: 'Anexar arquivos →',
              primary: true,
            },
            {
              icon: '◐',
              t: 'Builder manual',
              body: 'Monte unidades, atividades e avaliações sem documentos.',
              cta: 'Abrir Builder →',
            },
          ].map((c, i) => (
            <div key={i} style={{
              background: 'var(--surface)',
              border: c.primary ? '1px solid var(--accent)' : '1px solid var(--line)',
              borderRadius: 8, padding: '20px 22px',
              display: 'flex', flexDirection: 'column',
              boxShadow: c.primary ? '0 0 0 4px rgba(129,140,248,0.08)' : 'none',
            }}>
              <div style={{
                width: 32, height: 32, borderRadius: 6,
                background: c.primary ? 'var(--accent-soft)' : 'var(--surface-2)',
                color: c.primary ? 'var(--accent)' : 'var(--ink-2)',
                display: 'grid', placeItems: 'center', fontSize: 16,
                marginBottom: 12,
              }}>{c.icon}</div>
              <div style={{ fontSize: 15, fontWeight: 600, marginBottom: 6 }}>{c.t}</div>
              <div style={{ fontSize: 12.5, color: 'var(--ink-2)', lineHeight: 1.55, marginBottom: 16 }}>{c.body}</div>
              <button className="btn-reset" style={{
                marginTop: 'auto', alignSelf: 'flex-start',
                padding: '6px 12px', borderRadius: 5,
                background: c.primary ? 'var(--accent)' : 'var(--surface-2)',
                color: c.primary ? 'var(--bg)' : 'var(--ink)',
                border: c.primary ? 'none' : '1px solid var(--line-2)',
                fontSize: 12, fontWeight: 500,
              }}>{c.cta}</button>
            </div>
          ))}
        </div>

        <div style={{ marginTop: 32, paddingTop: 22, borderTop: '1px solid var(--line)', display: 'flex', justifyContent: 'center', gap: 16, fontSize: 11.5, fontFamily: 'var(--mono)', color: 'var(--ink-3)' }}>
          <span>ⓘ docs</span>
          <span>· vídeo de 2 min</span>
          <span>· template de exemplo</span>
        </div>
      </div>
    </div>
  </div>
);

/* ── B11 · Generating MBZ (loader) ──────────────── */
const B_Generating = () => (
  <div className="ab dir-b">
    <BNav active="new" />
    <main style={{ flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', padding: 40, position: 'relative' }}>
      <div style={{ position: 'absolute', inset: 0, background: 'radial-gradient(circle at 50% 40%, rgba(129,140,248,0.1), transparent 50%)', pointerEvents: 'none' }}/>
      <div style={{ width: 600, position: 'relative' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 14 }}>
          <div style={{ width: 8, height: 8, borderRadius: '50%', background: 'var(--accent)', boxShadow: '0 0 0 4px rgba(129,140,248,0.2)', animation: 'blink 1s infinite' }}/>
          <span style={{ fontFamily: 'var(--mono)', fontSize: 11, color: 'var(--ink-2)', textTransform: 'uppercase', letterSpacing: 0.8 }}>building · poo-2026.1</span>
        </div>
        <h1 style={{ fontSize: 32, fontWeight: 600, letterSpacing: -0.6, margin: '0 0 8px', lineHeight: 1.1 }}>
          Empacotando para o Moodle…
        </h1>
        <p style={{ fontSize: 13.5, color: 'var(--ink-2)', marginTop: 0, marginBottom: 24 }}>
          Em geral leva 20–40 segundos. Você pode fechar essa aba — vamos avisar.
        </p>

        {/* Steps with progress */}
        <div style={{ background: 'var(--surface)', border: '1px solid var(--line)', borderRadius: 8, padding: '16px 18px', marginBottom: 16 }}>
          {[
            { l: 'Validando JSON', s: 'done' },
            { l: 'Gerando XML do curso', s: 'done' },
            { l: 'Compilando atividades · 8 / 13', s: 'active', pct: 62 },
            { l: 'Empacotando .mbz', s: 'pending' },
            { l: 'Calculando hash sha1', s: 'pending' },
          ].map((step, i) => (
            <div key={i} style={{ display: 'flex', alignItems: 'center', gap: 12, padding: '8px 0', borderBottom: i < 4 ? '1px solid var(--line)' : 'none' }}>
              <div style={{
                width: 18, height: 18, borderRadius: '50%',
                background: step.s === 'done' ? 'var(--ok)' : step.s === 'active' ? 'var(--accent-soft)' : 'transparent',
                border: step.s === 'pending' ? '1px solid var(--line-2)' : 'none',
                display: 'grid', placeItems: 'center',
                color: step.s === 'done' ? 'var(--bg)' : 'var(--accent)',
                fontSize: 10, fontWeight: 700,
              }}>
                {step.s === 'done' && '✓'}
                {step.s === 'active' && <div style={{ width: 6, height: 6, borderRadius: '50%', background: 'var(--accent)', animation: 'blink 0.9s infinite' }}/>}
              </div>
              <div style={{ flex: 1, fontSize: 13, color: step.s === 'pending' ? 'var(--ink-3)' : 'var(--ink)' }}>{step.l}</div>
              {step.s === 'active' && (
                <div style={{ width: 110, height: 4, background: 'var(--surface-3)', borderRadius: 2, overflow: 'hidden' }}>
                  <div style={{ width: `${step.pct}%`, height: '100%', background: 'linear-gradient(90deg, var(--accent), var(--accent-2))' }}/>
                </div>
              )}
              {step.s === 'done' && <span style={{ fontFamily: 'var(--mono)', fontSize: 10, color: 'var(--ink-3)' }}>ok</span>}
            </div>
          ))}
        </div>

        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <span style={{ fontFamily: 'var(--mono)', fontSize: 11, color: 'var(--ink-3)' }}>elapsed 00:18 · ~12s restantes</span>
          <button className="btn-reset" style={{ padding: '6px 14px', borderRadius: 5, border: '1px solid var(--line-2)', background: 'var(--surface-2)', fontSize: 12, color: 'var(--ink-2)' }}>Cancelar</button>
        </div>
      </div>
    </main>
  </div>
);

/* ── B12 · Error state ──────────────────────────── */
const B_Error = () => (
  <div className="ab dir-b">
    <BNav active="new" />
    <main style={{ flex: 1, display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 40 }}>
      <div style={{ width: 580 }}>
        <div style={{ width: 44, height: 44, borderRadius: 10, background: 'rgba(248,113,113,0.12)', border: '1px solid rgba(248,113,113,0.3)', color: 'var(--danger)', display: 'grid', placeItems: 'center', fontSize: 22, marginBottom: 18 }}>!</div>
        <BBadge tone="danger">erro · gemini · 429</BBadge>
        <h1 style={{ fontSize: 28, fontWeight: 600, letterSpacing: -0.5, margin: '12px 0 8px', lineHeight: 1.15 }}>
          A extração não pôde ser concluída.
        </h1>
        <p style={{ fontSize: 14, color: 'var(--ink-2)', lineHeight: 1.6, marginTop: 0, marginBottom: 22 }}>
          O modelo Gemini retornou rate limit (quota mensal da chave do servidor esgotada). Configure sua própria chave para continuar agora, ou tente outro provedor.
        </p>

        <div style={{ background: 'var(--surface)', border: '1px solid var(--line)', borderRadius: 6, padding: '12px 14px', marginBottom: 14, fontFamily: 'var(--mono)', fontSize: 11.5, color: 'var(--ink-2)', lineHeight: 1.7 }}>
          <div style={{ color: 'var(--ink-3)' }}>// stack</div>
          <div><span style={{ color: 'var(--danger)' }}>error:</span> RateLimitError</div>
          <div><span style={{ color: 'var(--ink-3)' }}>at</span> generative-ai.ts:142</div>
          <div><span style={{ color: 'var(--ink-3)' }}>req-id:</span> r-A3f2c…91</div>
        </div>

        <div style={{ display: 'flex', gap: 8 }}>
          <button className="btn-reset" style={{ padding: '8px 16px', borderRadius: 5, background: 'var(--accent)', color: 'var(--bg)', fontSize: 13, fontWeight: 600 }}>Conectar minha chave →</button>
          <button className="btn-reset" style={{ padding: '8px 14px', borderRadius: 5, border: '1px solid var(--line-2)', background: 'var(--surface-2)', fontSize: 13, color: 'var(--ink)' }}>Trocar para OpenAI</button>
          <button className="btn-reset" style={{ padding: '8px 14px', borderRadius: 5, fontSize: 13, color: 'var(--ink-2)' }}>Tentar de novo</button>
        </div>
      </div>
    </main>
  </div>
);

/* ── B13 · Compartilhar revisão (modal) ─────────── */
const B_ShareModal = () => (
  <div className="ab dir-b" style={{ position: 'relative' }}>
    {/* background dimmed app */}
    <div style={{ position: 'absolute', inset: 0, opacity: 0.35, pointerEvents: 'none' }}>
      <BNav active="new" />
      <div style={{ height: 60, borderBottom: '1px solid var(--line)' }}/>
      <div style={{ display: 'grid', gridTemplateColumns: '260px 1fr 280px', height: 600 }}>
        <div style={{ borderRight: '1px solid var(--line)', background: 'var(--surface)' }}/>
        <div/>
        <div style={{ borderLeft: '1px solid var(--line)', background: 'var(--surface)' }}/>
      </div>
    </div>
    <div style={{ position: 'absolute', inset: 0, background: 'rgba(0,0,0,0.5)', backdropFilter: 'blur(2px)' }}/>

    {/* Modal */}
    <div style={{
      position: 'absolute', top: '50%', left: '50%', transform: 'translate(-50%, -50%)',
      width: 540, background: 'var(--surface)', border: '1px solid var(--line-2)',
      borderRadius: 10, boxShadow: '0 20px 60px rgba(0,0,0,0.5)',
      overflow: 'hidden',
    }}>
      <div style={{ padding: '16px 20px', borderBottom: '1px solid var(--line)', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
          <BBadge tone="accent">colaboração</BBadge>
          <span style={{ fontSize: 14, fontWeight: 600 }}>Compartilhar revisão</span>
        </div>
        <button className="btn-reset" style={{ color: 'var(--ink-3)', fontSize: 16 }}>×</button>
      </div>

      <div style={{ padding: 20 }}>
        <div style={{ fontSize: 12.5, color: 'var(--ink-2)', marginBottom: 14 }}>
          Qualquer pessoa com o link pode visualizar e comentar. A geração do .mbz exige sua aprovação.
        </div>

        <div style={{ display: 'flex', gap: 6, marginBottom: 18, background: 'var(--surface-2)', border: '1px solid var(--line)', borderRadius: 5, padding: '8px 10px' }}>
          <span style={{ fontFamily: 'var(--mono)', fontSize: 12, color: 'var(--ink)', flex: 1, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
            coursegen.ai/r/9F2a-3K7b-X...
          </span>
          <button className="btn-reset" style={{ fontSize: 11, padding: '3px 10px', borderRadius: 3, background: 'var(--accent)', color: 'var(--bg)', fontWeight: 500 }}>copiar</button>
        </div>

        <div style={{ fontSize: 11, fontFamily: 'var(--mono)', color: 'var(--ink-3)', textTransform: 'uppercase', letterSpacing: 0.5, marginBottom: 8 }}>permissão padrão</div>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 6, marginBottom: 18 }}>
          {[
            ['Visualizar', false],
            ['Comentar', true],
            ['Editar', false],
          ].map(([l, on], i) => (
            <button key={i} className="btn-reset" style={{
              padding: '7px 10px', borderRadius: 5, fontSize: 12.5,
              background: on ? 'var(--surface-3)' : 'transparent',
              color: on ? 'var(--ink)' : 'var(--ink-2)',
              border: `1px solid ${on ? 'var(--accent)' : 'var(--line)'}`,
              fontWeight: on ? 500 : 400,
            }}>{l}</button>
          ))}
        </div>

        <div style={{ fontSize: 11, fontFamily: 'var(--mono)', color: 'var(--ink-3)', textTransform: 'uppercase', letterSpacing: 0.5, marginBottom: 8 }}>convidar por e-mail</div>
        <div style={{ display: 'flex', gap: 6 }}>
          <input placeholder="professor@ifce.edu.br" style={{ flex: 1, background: 'var(--surface-2)', border: '1px solid var(--line)', borderRadius: 5, padding: '8px 12px', fontSize: 13, color: 'var(--ink)', outline: 0 }}/>
          <button className="btn-reset" style={{ padding: '8px 14px', borderRadius: 5, background: 'var(--ink)', color: 'var(--bg)', fontSize: 12.5, fontWeight: 500 }}>Convidar</button>
        </div>

        <div style={{ marginTop: 18, paddingTop: 14, borderTop: '1px solid var(--line)', fontSize: 11, fontFamily: 'var(--mono)', color: 'var(--ink-3)' }}>
          Acesso ativo: 3 pessoas · expira em 7 dias
        </div>
      </div>
    </div>
  </div>
);

window.B_Landing = B_Landing;
window.B_Onboarding = B_Onboarding;
window.B_EmptyHome = B_EmptyHome;
window.B_Generating = B_Generating;
window.B_Error = B_Error;
window.B_ShareModal = B_ShareModal;

/* B v3 — Drawer de Atividade (Quiz/Tarefa) com split view do .docx + Visualizador de arquivo */
const { BNav: BNavV3, BBadge: BBadgeV3 } = window;

/* Mock paper-styled doc preview (renderiza um .docx como se fosse uma folha A4) */
const DocPaper = ({ highlight, scrollTop, children }) => (
  <div style={{
    background: '#1a1a1f',
    borderRadius: 6,
    overflow: 'auto',
    padding: 0,
    height: '100%',
    position: 'relative',
  }}>
    <div style={{
      maxWidth: 480, margin: '20px auto',
      background: '#fafaf7', color: '#1a1815',
      borderRadius: 3, padding: '40px 48px',
      boxShadow: '0 8px 24px rgba(0,0,0,0.4), 0 1px 0 rgba(255,255,255,0.04)',
      fontFamily: '"Times New Roman", Georgia, serif',
      fontSize: 11.5, lineHeight: 1.7,
      minHeight: 600,
      position: 'relative',
    }}>
      {children}
    </div>
  </div>
);

const DocLine = ({ children, bold, h1, h2, hl, dim, indent }) => (
  <div style={{
    fontSize: h1 ? 16 : h2 ? 13 : 11.5,
    fontWeight: bold || h1 || h2 ? 700 : 400,
    marginBottom: h1 || h2 ? 12 : 8,
    marginTop: h1 || h2 ? 18 : 0,
    paddingLeft: indent ? 20 : 0,
    color: dim ? '#8a857d' : '#1a1815',
    background: hl ? 'rgba(129,140,248,0.18)' : 'transparent',
    padding: hl ? '2px 4px' : (indent ? '0 0 0 20px' : 0),
    borderLeft: hl ? '2px solid #818cf8' : 'none',
    marginLeft: hl ? -6 : 0,
    paddingLeft: hl ? 10 : (indent ? 20 : 0),
    borderRadius: hl ? 2 : 0,
  }}>{children}</div>
);

/* ── B14 · Drawer de Atividade (Quiz) com split view ─────────── */
const B_QuizDrawer = () => (
  <div className="ab dir-b" style={{ position: 'relative' }}>
    {/* Background: review screen dimmed */}
    <BNavV3 active="new" />
    <div style={{ flex: 1, display: 'grid', gridTemplateColumns: '260px 1fr', overflow: 'hidden', opacity: 0.45, pointerEvents: 'none' }}>
      <aside style={{ borderRight: '1px solid var(--line)', background: 'var(--surface)' }}>
        <div style={{ padding: '12px 14px', borderBottom: '1px solid var(--line)' }}>
          <div style={{ fontSize: 13, fontWeight: 600 }}>Programação OO</div>
          <div style={{ fontFamily: 'var(--mono)', fontSize: 10.5, color: 'var(--ink-3)' }}>TADS-POO · 80h</div>
        </div>
      </aside>
      <main style={{ padding: '20px 24px', background: 'var(--bg)' }}>
        <div style={{ height: 80, background: 'var(--surface)', border: '1px solid var(--line)', borderRadius: 6, marginBottom: 12 }}/>
        <div style={{ height: 200, background: 'var(--surface)', border: '1px solid var(--line)', borderRadius: 6 }}/>
      </main>
    </div>

    {/* Drawer overlay */}
    <div style={{
      position: 'absolute', top: 44, right: 0, bottom: 0,
      width: 920, background: 'var(--bg)',
      borderLeft: '1px solid var(--line-2)',
      boxShadow: '-20px 0 40px rgba(0,0,0,0.6)',
      display: 'flex', flexDirection: 'column',
    }}>
      {/* Drawer header */}
      <header style={{ padding: '14px 20px', borderBottom: '1px solid var(--line)', display: 'flex', alignItems: 'center', gap: 12, background: 'var(--surface)' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
          <button className="btn-reset" style={{ width: 24, height: 24, borderRadius: 4, color: 'var(--ink-3)', border: '1px solid var(--line)', fontSize: 11 }}>‹</button>
          <button className="btn-reset" style={{ width: 24, height: 24, borderRadius: 4, color: 'var(--ink-3)', border: '1px solid var(--line)', fontSize: 11 }}>›</button>
          <span style={{ fontFamily: 'var(--mono)', fontSize: 11, color: 'var(--ink-3)', marginLeft: 4 }}>3 de 4 nesta unidade</span>
        </div>
        <div style={{ flex: 1 }}/>
        <BBadgeV3 tone="default">Quiz</BBadgeV3>
        <span style={{ fontSize: 14, fontWeight: 600 }}>Q1 — Classes e objetos</span>
        <div style={{ flex: 1 }}/>
        <button className="btn-reset" style={{ fontSize: 11, color: 'var(--ink-2)', fontFamily: 'var(--mono)' }}>aprovar tudo ✓</button>
        <button className="btn-reset" style={{ width: 24, height: 24, borderRadius: 4, color: 'var(--ink-3)', fontSize: 16 }}>×</button>
      </header>

      {/* Quiz meta strip */}
      <div style={{ padding: '10px 20px', borderBottom: '1px solid var(--line)', display: 'flex', gap: 18, fontSize: 11, fontFamily: 'var(--mono)', color: 'var(--ink-2)', background: 'var(--surface-2)' }}>
        <span><span style={{ color: 'var(--ink-3)' }}>questões:</span> 10</span>
        <span><span style={{ color: 'var(--ink-3)' }}>tempo:</span> 60min</span>
        <span><span style={{ color: 'var(--ink-3)' }}>tentativas:</span> 2</span>
        <span><span style={{ color: 'var(--ink-3)' }}>nota mín:</span> 6.0</span>
        <span><span style={{ color: 'var(--ink-3)' }}>embaralhar:</span> sim</span>
        <div style={{ flex: 1 }}/>
        <span style={{ color: 'var(--accent-ink)' }}>fonte: questoes-u1.docx</span>
      </div>

      {/* Split: questões | docx preview */}
      <div style={{ flex: 1, display: 'grid', gridTemplateColumns: '1fr 380px', overflow: 'hidden' }}>

        {/* LEFT: questões */}
        <div style={{ overflow: 'auto', padding: '16px 20px', borderRight: '1px solid var(--line)' }}>
          <div style={{ fontSize: 10.5, fontFamily: 'var(--mono)', color: 'var(--ink-3)', textTransform: 'uppercase', letterSpacing: 0.5, marginBottom: 10 }}>questões extraídas pela IA</div>

          {/* Q1 — selected/expanded */}
          <article style={{
            background: 'var(--surface)',
            border: '1px solid var(--accent)',
            borderRadius: 6, padding: '14px 16px', marginBottom: 10,
            position: 'relative',
          }}>
            <div style={{ position: 'absolute', left: 0, top: 0, bottom: 0, width: 2, background: 'var(--accent)', borderRadius: 2 }}/>
            <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 8 }}>
              <span style={{ fontFamily: 'var(--mono)', fontSize: 11, color: 'var(--ink-3)' }}>Q1</span>
              <BBadgeV3 tone="default">múltipla escolha</BBadgeV3>
              <BBadgeV3 tone="ok">confiança alta</BBadgeV3>
              <div style={{ flex: 1 }}/>
              <span style={{ fontFamily: 'var(--mono)', fontSize: 10.5, color: 'var(--ink-3)' }}>1.0 pt</span>
            </div>
            <div style={{ fontSize: 13, color: 'var(--ink)', lineHeight: 1.55, marginBottom: 12 }}>
              Em programação orientada a objetos, qual a principal diferença entre <b>classe</b> e <b>objeto</b>?
            </div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 5, marginBottom: 12 }}>
              {[
                ['a', 'Classe é o molde, objeto é a instância concreta criada a partir desse molde.', true],
                ['b', 'Classe e objeto são sinônimos no paradigma OO.', false],
                ['c', 'Objeto é o molde, classe é a instância concreta.', false],
                ['d', 'Classe armazena dados, objeto armazena apenas métodos.', false],
              ].map(([letter, text, correct], i) => (
                <div key={i} style={{
                  display: 'flex', alignItems: 'flex-start', gap: 10,
                  padding: '8px 10px', borderRadius: 4,
                  background: correct ? 'rgba(74,222,128,0.08)' : 'transparent',
                  border: `1px solid ${correct ? 'rgba(74,222,128,0.25)' : 'var(--line)'}`,
                  fontSize: 12.5, color: correct ? 'var(--ink)' : 'var(--ink-2)',
                }}>
                  <span style={{
                    width: 18, height: 18, borderRadius: '50%',
                    border: `1.5px solid ${correct ? 'var(--ok)' : 'var(--line-2)'}`,
                    background: correct ? 'var(--ok)' : 'transparent',
                    color: correct ? 'var(--bg)' : 'transparent',
                    display: 'grid', placeItems: 'center', fontSize: 10, fontWeight: 700,
                    flexShrink: 0, marginTop: 1,
                  }}>{correct ? '✓' : ''}</span>
                  <span style={{ fontFamily: 'var(--mono)', fontSize: 11, color: correct ? 'var(--ok)' : 'var(--ink-3)', flexShrink: 0, marginTop: 1 }}>{letter})</span>
                  <span style={{ flex: 1, lineHeight: 1.5 }}>{text}</span>
                </div>
              ))}
            </div>
            <div style={{ paddingTop: 10, borderTop: '1px solid var(--line)', display: 'flex', alignItems: 'center', gap: 12, fontSize: 11.5 }}>
              <span style={{ fontFamily: 'var(--mono)', fontSize: 10.5, color: 'var(--ink-3)' }}>feedback:</span>
              <span style={{ flex: 1, color: 'var(--ink-2)', fontStyle: 'italic' }}>"A classe define a estrutura; o objeto é uma realização dela em memória."</span>
              <button className="btn-reset" style={{ color: 'var(--accent-ink)', fontFamily: 'var(--mono)', fontSize: 10.5 }}>ver no .docx →</button>
            </div>
            <div style={{ marginTop: 10, display: 'flex', gap: 6 }}>
              <button className="btn-reset" style={{ padding: '4px 10px', borderRadius: 3, background: 'var(--ok)', color: '#062a13', fontSize: 11, fontWeight: 600 }}>aprovar</button>
              <button className="btn-reset" style={{ padding: '4px 10px', borderRadius: 3, border: '1px solid var(--line-2)', background: 'var(--surface-2)', color: 'var(--ink-2)', fontSize: 11 }}>editar</button>
              <button className="btn-reset" style={{ padding: '4px 10px', borderRadius: 3, color: 'var(--danger)', fontSize: 11 }}>remover</button>
              <div style={{ flex: 1 }}/>
              <button className="btn-reset" style={{ padding: '4px 8px', color: 'var(--ink-3)', fontSize: 12 }}>▾</button>
            </div>
          </article>

          {/* Q2 — collapsed but visible content */}
          <article style={{
            background: 'var(--surface)',
            border: '1px solid var(--line)',
            borderRadius: 6, padding: '12px 16px', marginBottom: 8,
          }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 6 }}>
              <span style={{ fontFamily: 'var(--mono)', fontSize: 11, color: 'var(--ink-3)' }}>Q2</span>
              <BBadgeV3 tone="default">múltipla escolha</BBadgeV3>
              <BBadgeV3 tone="ok">alta</BBadgeV3>
              <div style={{ flex: 1 }}/>
              <span style={{ fontFamily: 'var(--mono)', fontSize: 10.5, color: 'var(--ink-3)' }}>1.0 pt</span>
              <span style={{ color: 'var(--ink-3)', fontSize: 12 }}>▸</span>
            </div>
            <div style={{ fontSize: 12.5, color: 'var(--ink-2)', lineHeight: 1.55 }}>
              Identifique a alternativa que descreve corretamente um <b>atributo de instância</b> em Python:
            </div>
          </article>

          {/* Q3 — warning (low confidence) */}
          <article style={{
            background: 'var(--surface)',
            border: '1px solid rgba(251,191,36,0.3)',
            borderRadius: 6, padding: '12px 16px', marginBottom: 8,
          }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 6 }}>
              <span style={{ fontFamily: 'var(--mono)', fontSize: 11, color: 'var(--ink-3)' }}>Q3</span>
              <BBadgeV3 tone="default">verdadeiro/falso</BBadgeV3>
              <BBadgeV3 tone="warn">confiança baixa</BBadgeV3>
              <div style={{ flex: 1 }}/>
              <span style={{ fontFamily: 'var(--mono)', fontSize: 10.5, color: 'var(--ink-3)' }}>1.0 pt</span>
              <span style={{ color: 'var(--ink-3)', fontSize: 12 }}>▸</span>
            </div>
            <div style={{ fontSize: 12.5, color: 'var(--ink-2)', lineHeight: 1.55, marginBottom: 6 }}>
              "Encapsulamento permite o acesso direto a atributos privados."
            </div>
            <div style={{ fontSize: 11, color: 'var(--warn)', display: 'flex', alignItems: 'center', gap: 6 }}>
              <span>⚠</span>
              <span>A IA reescreveu o enunciado — confira no .docx se a intenção bate.</span>
            </div>
          </article>

          {/* Q4-Q10 abbreviated */}
          {[4, 5, 6, 7, 8, 9, 10].map(n => (
            <article key={n} style={{
              background: 'var(--surface)',
              border: '1px solid var(--line)',
              borderRadius: 6, padding: '10px 16px', marginBottom: 6,
              display: 'flex', alignItems: 'center', gap: 8,
            }}>
              <span style={{ fontFamily: 'var(--mono)', fontSize: 11, color: 'var(--ink-3)', minWidth: 22 }}>Q{n}</span>
              <BBadgeV3 tone="default">{n % 2 === 0 ? 'múltipla' : 'v/f'}</BBadgeV3>
              <span style={{ flex: 1, fontSize: 12, color: 'var(--ink-2)', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                {n === 4 && 'Qual visibilidade torna um atributo acessível somente dentro da própria classe?'}
                {n === 5 && 'Em UML, qual símbolo representa visibilidade pública?'}
                {n === 6 && 'O que é um método construtor e qual sua função na criação de objetos?'}
                {n === 7 && 'Diferencie sobrecarga e sobrescrita de métodos…'}
                {n === 8 && 'A herança simples permite que uma classe herde de duas superclasses.'}
                {n === 9 && 'Identifique o conceito ilustrado pelo trecho de código apresentado…'}
                {n === 10 && 'Cite três vantagens do uso de classes em projetos médios e grandes.'}
              </span>
              <span style={{ fontFamily: 'var(--mono)', fontSize: 10.5, color: 'var(--ink-3)' }}>1.0 pt</span>
              <span style={{ color: 'var(--ink-3)', fontSize: 12 }}>▸</span>
            </article>
          ))}

          <button className="btn-reset" style={{ marginTop: 10, padding: '8px 12px', textAlign: 'left', border: '1px dashed var(--line-2)', borderRadius: 5, color: 'var(--ink-3)', fontSize: 12, fontFamily: 'var(--mono)', width: '100%' }}>+ adicionar questão</button>
        </div>

        {/* RIGHT: docx preview */}
        <div style={{ display: 'flex', flexDirection: 'column', minWidth: 0, background: 'var(--surface)' }}>
          <div style={{ padding: '10px 14px', borderBottom: '1px solid var(--line)', display: 'flex', alignItems: 'center', gap: 8 }}>
            <div style={{ width: 14, height: 16, background: 'var(--surface-3)', borderRadius: 2, fontFamily: 'var(--mono)', fontSize: 6.5, color: 'var(--ink-3)', display: 'grid', placeItems: 'center', letterSpacing: 0.3, flexShrink: 0 }}>DOC</div>
            <span style={{ fontSize: 11.5, fontFamily: 'var(--mono)', color: 'var(--ink-2)', flex: 1, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>questoes-u1.docx</span>
            <button className="btn-reset" style={{ fontSize: 10.5, color: 'var(--ink-3)', fontFamily: 'var(--mono)' }}>↗</button>
            <button className="btn-reset" style={{ fontSize: 10.5, color: 'var(--ink-3)', fontFamily: 'var(--mono)' }}>↓</button>
          </div>
          <div style={{ padding: '4px 8px', borderBottom: '1px solid var(--line)', display: 'flex', alignItems: 'center', gap: 6, fontSize: 10.5, fontFamily: 'var(--mono)', color: 'var(--ink-3)' }}>
            <span>página 1 de 6</span>
            <div style={{ flex: 1 }}/>
            <button className="btn-reset" style={{ padding: '2px 6px' }}>−</button>
            <span>100%</span>
            <button className="btn-reset" style={{ padding: '2px 6px' }}>+</button>
            <span style={{ width: 1, height: 12, background: 'var(--line)', margin: '0 4px' }}/>
            <span style={{ color: 'var(--accent)' }}>↕ rolando junto com Q1</span>
          </div>
          <DocPaper>
            <DocLine h2>Questões — Unidade 1</DocLine>
            <DocLine dim>Disciplina: TADS-POO · Período 2026.1</DocLine>
            <div style={{ height: 12 }}/>
            <DocLine bold>Questão 1.</DocLine>
            <DocLine hl>Em programação orientada a objetos, qual a principal diferença entre <b>classe</b> e <b>objeto</b>?</DocLine>
            <DocLine indent hl>a) Classe é o molde, objeto é a instância concreta criada a partir desse molde. <b>(correta)</b></DocLine>
            <DocLine indent hl>b) Classe e objeto são sinônimos no paradigma OO.</DocLine>
            <DocLine indent hl>c) Objeto é o molde, classe é a instância concreta.</DocLine>
            <DocLine indent hl>d) Classe armazena dados, objeto armazena apenas métodos.</DocLine>
            <div style={{ height: 12 }}/>
            <DocLine bold>Questão 2.</DocLine>
            <DocLine>Identifique a alternativa que descreve corretamente um atributo de instância em Python:</DocLine>
            <DocLine indent>a) declarado dentro do método construtor com self.</DocLine>
            <DocLine indent dim>(restante da página…)</DocLine>
          </DocPaper>
        </div>
      </div>

      {/* Drawer footer */}
      <footer style={{ padding: '10px 20px', borderTop: '1px solid var(--line)', background: 'var(--surface)', display: 'flex', alignItems: 'center', gap: 10 }}>
        <BBadgeV3 tone="ok">8 aprovadas</BBadgeV3>
        <BBadgeV3 tone="warn">1 com aviso</BBadgeV3>
        <BBadgeV3 tone="default">1 não revisada</BBadgeV3>
        <div style={{ flex: 1 }}/>
        <button className="btn-reset" style={{ padding: '6px 12px', borderRadius: 4, fontSize: 12, color: 'var(--ink-2)' }}>Voltar</button>
        <button className="btn-reset" style={{ padding: '6px 14px', borderRadius: 4, background: 'var(--accent)', color: 'var(--bg)', fontSize: 12, fontWeight: 600 }}>Aprovar quiz e voltar →</button>
      </footer>
    </div>
  </div>
);

/* ── B15 · Visualizador da Matriz (file viewer) ────── */
const B_FileViewer = () => (
  <div className="ab dir-b" style={{ position: 'relative' }}>
    <BNavV3 active="new" />
    <div style={{ flex: 1, opacity: 0.4, pointerEvents: 'none', background: 'var(--bg)' }}/>

    <div style={{
      position: 'absolute', top: 44, right: 0, bottom: 0,
      width: 1080, background: 'var(--bg)',
      borderLeft: '1px solid var(--line-2)',
      boxShadow: '-20px 0 40px rgba(0,0,0,0.6)',
      display: 'flex', flexDirection: 'column',
    }}>
      <header style={{ padding: '14px 20px', borderBottom: '1px solid var(--line)', display: 'flex', alignItems: 'center', gap: 12, background: 'var(--surface)' }}>
        <div style={{ width: 24, height: 28, background: 'var(--surface-3)', borderRadius: 3, fontFamily: 'var(--mono)', fontSize: 8, color: 'var(--ink-3)', display: 'grid', placeItems: 'center', letterSpacing: 0.3 }}>DOC</div>
        <div style={{ flex: 1 }}>
          <div style={{ fontSize: 13, fontWeight: 600 }}>matriz-poo-2026.1.docx</div>
          <div style={{ fontFamily: 'var(--mono)', fontSize: 10.5, color: 'var(--ink-3)' }}>78 KB · 4 páginas · enviado há 18 min</div>
        </div>
        <button className="btn-reset" style={{ padding: '5px 12px', borderRadius: 4, fontSize: 11.5, color: 'var(--ink-2)', border: '1px solid var(--line-2)', background: 'var(--surface-2)' }}>↗ abrir original</button>
        <button className="btn-reset" style={{ padding: '5px 12px', borderRadius: 4, fontSize: 11.5, color: 'var(--ink-2)', border: '1px solid var(--line-2)', background: 'var(--surface-2)' }}>↓ baixar</button>
        <button className="btn-reset" style={{ width: 24, height: 24, borderRadius: 4, color: 'var(--ink-3)', fontSize: 16, marginLeft: 4 }}>×</button>
      </header>

      <div style={{ padding: '8px 20px', borderBottom: '1px solid var(--line)', display: 'flex', alignItems: 'center', gap: 8, fontSize: 11, fontFamily: 'var(--mono)', color: 'var(--ink-3)', background: 'var(--surface-2)' }}>
        <span style={{ width: 6, height: 6, borderRadius: '50%', background: 'var(--accent)' }}/>
        <span style={{ color: 'var(--accent-ink)' }}>5 trechos destacados</span>
        <span>geraram conteúdo no JSON</span>
        <div style={{ flex: 1 }}/>
        <button className="btn-reset" style={{ padding: '2px 8px' }}>− zoom</button>
        <span>100%</span>
        <button className="btn-reset" style={{ padding: '2px 8px' }}>+ zoom</button>
      </div>

      <div style={{ flex: 1, display: 'grid', gridTemplateColumns: '180px 1fr 280px', overflow: 'hidden' }}>

        {/* Pages thumbs */}
        <aside style={{ borderRight: '1px solid var(--line)', background: 'var(--surface)', padding: 12, overflow: 'auto' }}>
          <div style={{ fontSize: 10, fontFamily: 'var(--mono)', color: 'var(--ink-3)', textTransform: 'uppercase', letterSpacing: 0.5, marginBottom: 10 }}>páginas</div>
          {[1, 2, 3, 4].map(n => (
            <div key={n} style={{
              marginBottom: 10, padding: 6,
              border: n === 1 ? '2px solid var(--accent)' : '1px solid var(--line)',
              borderRadius: 3, background: 'var(--bg)',
              cursor: 'pointer',
            }}>
              <div style={{ background: '#fafaf7', height: 110, borderRadius: 1, padding: '8px 10px', position: 'relative' }}>
                <div style={{ width: '100%', height: 4, background: '#1a1815', marginBottom: 4, borderRadius: 1 }}/>
                <div style={{ width: '70%', height: 2, background: '#8a857d', marginBottom: 6 }}/>
                {n === 1 && <div style={{ position: 'absolute', left: 8, top: 22, right: 8, height: 12, background: 'rgba(129,140,248,0.4)', borderRadius: 1 }}/>}
                <div style={{ width: '100%', height: 2, background: '#5a564f', marginBottom: 2, marginTop: n === 1 ? 18 : 6 }}/>
                <div style={{ width: '92%', height: 2, background: '#5a564f', marginBottom: 2 }}/>
                <div style={{ width: '88%', height: 2, background: '#5a564f', marginBottom: 2 }}/>
                {n === 2 && <div style={{ width: '60%', height: 8, background: 'rgba(129,140,248,0.4)', borderRadius: 1, marginTop: 6 }}/>}
                <div style={{ width: '94%', height: 2, background: '#5a564f', marginBottom: 2, marginTop: 4 }}/>
                <div style={{ width: '86%', height: 2, background: '#5a564f' }}/>
              </div>
              <div style={{ fontSize: 10, fontFamily: 'var(--mono)', color: 'var(--ink-3)', textAlign: 'center', marginTop: 4 }}>pg {n}</div>
            </div>
          ))}
        </aside>

        {/* Doc paper */}
        <div style={{ overflow: 'auto', padding: 20, background: 'var(--bg)' }}>
          <div style={{
            maxWidth: 540, margin: '0 auto',
            background: '#fafaf7', color: '#1a1815',
            borderRadius: 3, padding: '48px 56px',
            boxShadow: '0 8px 24px rgba(0,0,0,0.4)',
            fontFamily: '"Times New Roman", Georgia, serif',
            fontSize: 12, lineHeight: 1.7,
            minHeight: 700,
          }}>
            <div style={{ textAlign: 'center', marginBottom: 24 }}>
              <DocLine h1>MATRIZ DA DISCIPLINA</DocLine>
              <DocLine dim>Curso: Tecnologia em Análise e Desenvolvimento de Sistemas</DocLine>
              <DocLine dim>Disciplina: Programação Orientada a Objetos</DocLine>
            </div>

            <DocLine h2>1. Identificação</DocLine>
            <DocLine hl><b>Código:</b> TADS-POO &nbsp;&nbsp; <b>Carga horária:</b> 80h &nbsp;&nbsp; <b>Período:</b> 2026.1</DocLine>
            <DocLine hl><b>Pré-requisitos:</b> Algoritmos I (TADS-ALG1)</DocLine>
            <div style={{ height: 8 }}/>

            <DocLine h2>2. Ementa</DocLine>
            <DocLine hl>
              Conceitos de orientação a objetos. Classes, objetos, atributos, métodos.
              Encapsulamento, herança e polimorfismo. Aplicações em Python e Java.
              Padrões de projeto introdutórios. Boas práticas de modelagem com UML.
            </DocLine>
            <div style={{ height: 8 }}/>

            <DocLine h2>3. Objetivos</DocLine>
            <DocLine>Ao final da disciplina, o aluno deverá ser capaz de:</DocLine>
            <DocLine hl indent>· Compreender e aplicar os princípios da orientação a objetos.</DocLine>
            <DocLine hl indent>· Modelar sistemas usando diagramas de classes UML.</DocLine>
            <DocLine indent>· Implementar classes, herança e polimorfismo em Python e Java.</DocLine>
            <DocLine indent>· Avaliar criticamente projetos OO de pequeno e médio porte.</DocLine>
          </div>
        </div>

        {/* Right: extraction map */}
        <aside style={{ borderLeft: '1px solid var(--line)', background: 'var(--surface)', overflow: 'auto', padding: '14px 16px' }}>
          <div style={{ fontSize: 10.5, fontFamily: 'var(--mono)', color: 'var(--ink-3)', textTransform: 'uppercase', letterSpacing: 0.5, marginBottom: 10 }}>O que a IA extraiu daqui</div>

          {[
            { trecho: 'pg 1 · Código, carga, pré-req', destino: 'Identificação', ok: true },
            { trecho: 'pg 1 · "Conceitos de OO…"', destino: 'Ementa', warn: true },
            { trecho: 'pg 1 · "deverá ser capaz de:" + 2 itens', destino: 'Objetivos[0..1]', ok: true },
            { trecho: 'pg 2 · Unidade I — Conceitos', destino: 'Unidade 1', ok: true },
            { trecho: 'pg 3 · Unidade II — Herança', destino: 'Unidade 2', ok: true },
          ].map((m, i) => (
            <div key={i} style={{
              marginBottom: 10,
              padding: '10px 12px',
              background: 'var(--bg)',
              border: '1px solid var(--line)',
              borderRadius: 5,
              fontSize: 11.5,
            }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 6, marginBottom: 6 }}>
                <span style={{ width: 6, height: 6, borderRadius: '50%', background: m.warn ? 'var(--warn)' : 'var(--accent)' }}/>
                <span style={{ fontFamily: 'var(--mono)', fontSize: 10.5, color: 'var(--ink-3)' }}>{m.trecho}</span>
              </div>
              <div style={{ fontSize: 12, color: 'var(--ink-2)', display: 'flex', alignItems: 'center', gap: 6 }}>
                <span>→</span>
                <span style={{ color: m.warn ? 'var(--warn)' : 'var(--accent-ink)', fontWeight: 500 }}>{m.destino}</span>
                {m.warn && <span style={{ marginLeft: 'auto', fontSize: 10, color: 'var(--warn)' }}>truncado</span>}
              </div>
            </div>
          ))}

          <div style={{ marginTop: 18, padding: '10px 12px', background: 'rgba(129,140,248,0.06)', border: '1px solid rgba(129,140,248,0.2)', borderRadius: 5, fontSize: 11.5, color: 'var(--ink-2)', lineHeight: 1.55 }}>
            <div style={{ fontFamily: 'var(--mono)', fontSize: 10, color: 'var(--accent-ink)', textTransform: 'uppercase', letterSpacing: 0.5, marginBottom: 4 }}>dica</div>
            Clique em qualquer trecho destacado <span style={{ background: 'rgba(129,140,248,0.18)', padding: '0 4px', borderRadius: 1 }}>assim</span> no documento para pular direto pro item gerado no JSON.
          </div>
        </aside>
      </div>

      <footer style={{ padding: '10px 20px', borderTop: '1px solid var(--line)', background: 'var(--surface)', display: 'flex', alignItems: 'center', gap: 10, fontSize: 11.5, color: 'var(--ink-2)' }}>
        <span style={{ fontFamily: 'var(--mono)', fontSize: 11, color: 'var(--ink-3)' }}>arquivo armazenado localmente · IndexedDB</span>
        <div style={{ flex: 1 }}/>
        <button className="btn-reset" style={{ padding: '6px 12px', borderRadius: 4, fontSize: 12, color: 'var(--ink-2)', border: '1px solid var(--line-2)', background: 'var(--surface-2)' }}>Substituir arquivo</button>
        <button className="btn-reset" style={{ padding: '6px 14px', borderRadius: 4, background: 'var(--accent)', color: 'var(--bg)', fontSize: 12, fontWeight: 600 }}>Voltar para Revisão →</button>
      </footer>
    </div>
  </div>
);

window.B_QuizDrawer = B_QuizDrawer;
window.B_FileViewer = B_FileViewer;

# Handoff: CourseGen AI — Dark redesign + novas funcionalidades

## Overview

Este pacote contém o redesign completo do **CourseGen AI** (gerador de pacotes Moodle `.mbz` a partir de documentos `.docx`) em tema escuro, mais a especificação de várias funcionalidades novas pedidas pelo product owner:

1. Configuração da chave da API do Gemini pelo próprio usuário (com fallback para a `GEMINI_KEY` do servidor) e suporte multi-modelo (Gemini, OpenAI, Claude).
2. Tela inicial repensada com 2 estados (Em construção / Finalizada) numa só listagem.
3. Fluxo principal: Upload → Revisão → Gerando → Finalizada.
4. Revisão em **Blocos** (default) ou **JSON** (alternativo) + modo **Diff**.
5. Drawer da atividade com **split view do .docx original** ao lado das questões extraídas pela IA.
6. Visualizador de arquivo (`.docx`/PDF) com mapa de extração mostrando que trecho gerou que parte do JSON.
7. Estados de erro (rate limit, chave inválida, etc.).

## About the Design Files

Os arquivos HTML/JSX deste bundle são **referências de design** — protótipos React em Babel inline mostrando o look-and-feel e o comportamento pretendido. **Não são código de produção**.

A tarefa é **recriar essas telas no codebase existente do CourseGen AI** (`https://github.com/juanfernandez13/CourseGen-AI`) usando o ambiente já estabelecido lá: **Next.js + React + Tailwind v4** dentro da pasta `ui/`. A persistência atual é localStorage (com a limitação de não armazenar arquivos binários) — esta funcionalidade deve ser estendida para usar **IndexedDB para armazenar os Blobs dos `.docx`/PDF**, mantendo o JSON do curso no localStorage como já está.

## Fidelity

**High-fidelity.** Cores, tipografia, espaçamento, microcopy e estados estão definidos. Todos os valores estão em `tokens.css` na variante `.dir-b` (ignorar `.dir-a` e `.dir-c` — eram outras direções já descartadas pelo PO).

Pixel-perfect não é o objetivo final — o objetivo é **fidelidade visual e de interação**. Onde o codebase existente já tiver um componente equivalente (botão, badge, tabela), use o componente do codebase ajustado para os tokens novos abaixo, em vez de recriar do zero.

---

## Design tokens (consolidados de `tokens.css` → `.dir-b`)

```css
/* Backgrounds */
--bg:        #0a0a0c;   /* canvas de fundo */
--surface:   #111114;   /* cards, sidebars */
--surface-2: #16161a;   /* sub-superfícies, headers */
--surface-3: #1c1c22;   /* hover/selected, code blocks */

/* Lines */
--line:   #1f1f25;      /* divisores sutis */
--line-2: #2a2a32;      /* divisores fortes, borders de input */

/* Ink (texto) */
--ink:    #ededf0;      /* primário */
--ink-2:  #a1a1aa;      /* secundário */
--ink-3:  #71717a;      /* terciário, mono labels */

/* Accent (indigo) */
--accent:     #818cf8;  /* CTA primário, links */
--accent-2:   #a78bfa;  /* gradient pair */
--accent-ink: #c7d2fe;  /* texto sobre superfícies escuras */

/* Status */
--ok:     #4ade80;      /* sucesso */
--warn:   #fbbf24;      /* atenção, baixa confiança da IA */
--danger: #f87171;      /* destrutivo, erro */

/* Type */
--sans: 'Geist', 'Inter', system-ui, sans-serif;
--mono: 'Geist Mono', 'JetBrains Mono', ui-monospace, monospace;

/* Radii */
--r-sm: 3px;   /* badges, inputs pequenos */
--r-md: 5px;   /* botões, cards densos */
--r-lg: 8px;   /* cards principais */
```

**Tipografia (referência rápida):**
- Heading de tela: 22px / weight 600 / letter-spacing -0.4px
- Heading de seção: 14–16px / weight 600 / letter-spacing -0.2px
- Body: 12.5–13px / line-height 1.55–1.6
- Mono labels (UPPERCASE, letter-spacing 0.5px): 10–11px
- Mono inline (paths, ids, metadados): 10.5–11.5px

**Sombras / elevações:**
- Drawer overlay: `box-shadow: -20px 0 40px rgba(0,0,0,0.6)` na borda esquerda
- Background atrás do drawer: `opacity: 0.4–0.45`, `pointer-events: none`
- Documento "papel" (preview .docx): `box-shadow: 0 8px 24px rgba(0,0,0,0.4)`

**Densidade:** todas as ações inline têm padding vertical 4–6px / horizontal 10–14px. Ícones 14–16px. Linha-base de tabela: 36–40px. **Não inflar** — a estética é Linear/Vercel-like, densa e técnica.

---

## Screens / Views

Todas as telas usam o mesmo shell: barra de navegação superior `<BNav>` (logo "CourseGen", links Disciplinas/Nova/Configurações, avatar à direita) + área de conteúdo. O shell vive em `dir-b.jsx`.

### 1. Home — Lista única com 2 estados (`dir-b-home.jsx` → `B_HomeV2`)

**Propósito:** ponto de entrada. Lista todas as disciplinas do usuário em uma só tabela, filtrável por estado.

**Layout:**
- Header da tela: título "Disciplinas" + subtítulo + botão `+ Nova disciplina` (CTA primário, indigo).
- Linha de tabs/filtros: `Todas (N)` · `Em construção (N)` · `Finalizadas (N)`. Tab ativo tem borda inferior 2px indigo.
- Tabela densa com colunas: nome + código, estado (badge), progresso ou tamanho do .mbz, "editado há X" (mono), ação ("continuar →" ou "↓ baixar .mbz").
- Footer: indicador "armazenamento local · ~3.4 MB usado" em mono pequeno.

**Estados das linhas:**
- **Em construção:** badge `tone="accent"` ("Revisão" / "Upload" / "Gerando"), barra de progresso 3px indigo, link "continuar →".
- **Finalizada:** badge `tone="ok"` ("Pronta"), tamanho do .mbz em mono, link "↓ baixar .mbz".
- **Atenção (arquivos expirados):** badge `tone="warn"`, link "Reanexar arquivos →" em vez de continuar.

**Empty state:** placeholder grande no centro, ícone abstrato + microcopy "Suba sua matriz de disciplina pra começar" + CTA "+ Nova disciplina".

### 2. Upload (`dir-b.jsx` → `B_Upload`)

**Propósito:** o usuário sobe a Matriz (obrigatório) e arquivos opcionais de quizzes/tarefas; a IA extrai em tempo real.

**Layout:**
- Coluna esquerda (~360px): lista de tipos de documento (Matriz, Quizzes, Tarefas) cada um com sua dropzone densa. Matriz é obrigatória, outros são opcionais.
- Coluna direita (flex-1): **log da IA ao vivo** — terminal-like, fundo `--surface-2`, fonte mono, com timestamps `[hh:mm:ss]` em `--ink-3` e linhas de status:
  - `parseando matriz-poo-2026.1.docx…` → cinza
  - `✓ identificou 3 unidades` → verde
  - `⚠ ementa truncada em 240 chars` → amarelo
  - `✗ rate limit em gemini-1.5-pro, fallback para -flash` → vermelho
- Cursor piscando no fim do log (`@keyframes blink`).
- Footer fixo: "Cancelar" (ghost) + "Continuar para revisão →" (primário, habilitado quando matriz processada).

**Nota técnica:** o log deve ser stream-based (Server-Sent Events ou WebSocket) — não polling. Usar a API do Gemini com `streamGenerateContent` quando possível.

### 3. Revisão — modo Blocos (default) (`dir-b-v2.jsx` → `B_ReviewBlocks`)

**Propósito:** professor revisa o que a IA extraiu antes de gerar o `.mbz`.

**Layout (3 colunas):**

**Esquerda (260px):** árvore de outline da disciplina.
- Header: nome da disciplina em 13px / 600, código + carga em mono 10.5px.
- Lista de seções: Identificação, Ementa, Objetivos, Unidade 1 (com filhos indentados: Fórum, Wiki, Quiz, Tarefa), Unidade 2, etc.
- Item ativo tem fundo `--surface-3` e weight 500.
- Cada item de unidade tem `▾`/`▸` para colapsar.
- Botão final: `+ Adicionar unidade` em itálico, cor `--ink-3`.

**Centro (flex-1):** blocos editáveis.
- Toggle no topo: `Blocos` (ativo) / `{ } JSON` / `Diff`. Estilo de pill group.
- Cards por seção. Cada card tem header `[ICONE] [TÍTULO] [BADGES]` + corpo editável + footer com ações inline (`editar`, `aprovar`, `pular`).
- Atividades dentro de unidades aparecem como sub-cards menores, com badge do tipo (`Quiz`, `Tarefa`, `Wiki`, `Fórum`) e meta-info (mono 10.5px): `10 questões · 60min · 2 tentativas`.
- **Clique em uma atividade abre o drawer** (ver tela 5).

**Direita (280px):** painel de arquivos + IA.
- Seção "Arquivos do upload": lista de `.docx`/PDF anexados, cada um com nome, tamanho, e dois botões `↗` (abrir visualizador) e `↓` (download).
- Seção "Sugestão da IA": card com fundo `rgba(129,140,248,0.06)` e borda indigo 0.2 alpha, contendo nota inteligente do tipo "A ementa parece truncada — quer que eu reescreva?" + botões "Aceitar" / "Ignorar".

**Footer:** "1 alerta · 2 dicas" (mono `--ink-3`) + botão "Pré-visualizar" + CTA primário "Gerar .mbz →".

### 4. Revisão — modo JSON (alternativo) (`dir-b.jsx` → `B_Review`)

**Propósito:** usuários técnicos editam o JSON cru. Mesmas 3 colunas, mas o centro vira um editor de código.

**Layout do centro:**
- Editor com gutter de números de linha (mono, `--ink-3`).
- Syntax highlighting básico: keys em `--accent-ink`, strings em `--ok`, números em `--warn`.
- Sticky toolbar com `▸ Identificação`, `▸ Unidades`, breadcrumbs do path JSON.
- Erros de schema marcam a linha em vermelho com tooltip explicativo.

**Recomendação técnica:** Monaco Editor ou CodeMirror 6, configurado com schema JSON do CourseGen para autocomplete e validação inline.

### 5. Drawer da Atividade — Quiz com split view (`dir-b-v3.jsx` → `B_QuizDrawer`)

**Propósito:** professor abre uma atividade pra revisar **cada questão** lado a lado com o `.docx` original que a IA usou — tela mais importante de toda a revisão.

**Estrutura:** drawer absoluto à direita, 920px largo, ocupando do topo da nav até o bottom. Background atrás fica `opacity: 0.45`. Sombra `-20px 0 40px rgba(0,0,0,0.6)`.

**Header do drawer:**
- Botões `‹` / `›` para navegar entre atividades **da mesma unidade** sem fechar.
- Indicador "3 de 4 nesta unidade" em mono.
- Badge `Quiz` + título "Q1 — Classes e objetos".
- Link "aprovar tudo ✓" + botão fechar `×`.

**Strip de meta:** linha mono com `questões: 10 · tempo: 60min · tentativas: 2 · nota mín: 6.0 · embaralhar: sim · fonte: questoes-u1.docx`.

**Body — split 1fr / 380px:**

**Esquerda (questões):**
- Card por questão. A selecionada tem borda 1px `--accent` + barra lateral de 2px indigo.
- Cabeçalho do card: `Q1` + badge tipo (múltipla escolha / verdadeiro-falso / dissertativa) + badge confiança (`alta` verde / `média` amarela / `baixa` amarela) + pontuação em mono.
- Enunciado em 13px line-height 1.55.
- Alternativas em lista vertical: cada uma com radio circle, letra `a)`, texto. **Correta** tem fundo `rgba(74,222,128,0.08)`, borda `rgba(74,222,128,0.25)`, radio preenchido com `✓` branco em fundo verde.
- Linha de feedback: label mono `feedback:` + texto em itálico `--ink-2` + link "ver no .docx →".
- Footer do card: botões `aprovar` (verde sólido), `editar` (ghost), `remover` (texto vermelho).
- Cards não selecionados: colapsados, mostram só Q-N + badge tipo + preview do enunciado em uma linha (truncado), seta `▸`.
- Card com aviso (confiança baixa): borda amarela 0.3 alpha, linha de aviso "⚠ A IA reescreveu o enunciado — confira no .docx se a intenção bate."

**Direita (preview do .docx):**
- Header: ícone DOC genérico + nome do arquivo (mono) + botões `↗` (abrir) `↓` (baixar).
- Toolbar abaixo: `página 1 de N` · zoom `−` `100%` `+` · indicador `↕ rolando junto com Q1`.
- Conteúdo: documento renderizado como **folha A4** (largura ~480px, padding 40×48px, fundo `#fafaf7`, texto `#1a1815`, font Times New Roman, line-height 1.7, sombra dramática). Trechos que originaram a Q1 ficam destacados em `rgba(129,140,248,0.18)` com borda esquerda 2px indigo.

**Comportamento crítico:** clicar em "ver no .docx →" rola o painel direito até o trecho correspondente. Selecionar outra questão na esquerda atualiza os highlights e rola o documento.

**Footer:** badges resumo (`8 aprovadas · 1 com aviso · 1 não revisada`) + botão Voltar + CTA "Aprovar quiz e voltar →".

### 6. Visualizador de arquivo (`dir-b-v3.jsx` → `B_FileViewer`)

**Propósito:** clicar em qualquer `.docx`/PDF na lista de arquivos abre este visualizador fullscreen-ish.

**Estrutura:** drawer 1080px à direita.

**Header:** thumbnail genérico de DOC + nome + meta ("78 KB · 4 páginas · enviado há 18 min") + `↗ abrir original` + `↓ baixar` + `×`.

**Strip:** indicador `5 trechos destacados geraram conteúdo no JSON` + zoom controls.

**Body — 3 colunas (180px / 1fr / 280px):**

**Esquerda (thumbnails):** uma miniatura por página, página ativa tem borda 2px indigo. Thumbnails são representações esquemáticas (linhas que sugerem texto + retângulos indigo onde há trechos destacados).

**Centro (papel):** documento renderizado como folha A4 (mesmas regras do preview do drawer mas mais largo, ~540px). Trechos destacados em `rgba(129,140,248,0.18)`. Headings da matriz seguem hierarquia: `h1` 16px bold center, `h2` 13px bold left, body 12px serif.

**Direita (mapa de extração):**
- Card por trecho destacado. Cada um mostra: bullet indigo · localização do trecho (mono `pg 1 · "trecho..."`) · seta `→` · destino no JSON em `--accent-ink` (`Identificação`, `Ementa`, `Unidade 1`, etc.).
- Trechos com problema (`Ementa` truncada): bullet amarelo, badge `truncado` à direita.
- Card final com fundo indigo translúcido: dica "Clique em qualquer trecho destacado no documento para pular direto pro item gerado no JSON".

**Footer:** mono `arquivo armazenado localmente · IndexedDB` + botão "Substituir arquivo" + CTA "Voltar para Revisão →".

### 7. Gerando .mbz (`dir-b-intro.jsx` → `B_Generating`)

**Propósito:** feedback durante a empacotamento final.

**Layout:** centralizado.
- Spinner ou progress indicador grande no centro.
- Título "Gerando pacote Moodle…" + subtítulo com a etapa atual.
- Lista de etapas com checkmarks: `✓ Validando estrutura · ✓ Empacotando recursos · ◌ Comprimindo .mbz · · Calculando hash`.
- Botão "Cancelar" discreto.

### 8. Finalizada · download (`dir-b.jsx` → `B_Done`)

**Propósito:** download do `.mbz` + opções pós-geração.

**Layout:** card grande centralizado.
- Ícone de sucesso (checkmark verde grande, possivelmente com circle `--ok` translúcido atrás).
- Título "Pronto!" + nome da disciplina.
- Stats inline: tamanho do .mbz, número de atividades, tempo de geração.
- CTA primário grande: `↓ Baixar disciplina-poo.mbz`.
- Ações secundárias: "Voltar para a lista" · "Gerar outra".

### 9. Erro · rate limit (`dir-b-intro.jsx` → `B_Error`)

**Propósito:** estado de erro genérico — usado para rate limit, chave inválida, falha de rede.

**Layout:** card centralizado, estilo similar ao Done mas com tom warning/danger.
- Ícone de aviso amarelo ou vermelho.
- Título "Limite atingido" / "Chave inválida" / etc.
- Explicação curta + sugestão de ação ("Aguarde 60s e tente de novo" ou "Verifique sua chave em Configurações").
- CTA primário: "Tentar de novo".
- Link secundário: "Ir para Configurações".

### 10. Settings · Modelos de IA (`dir-b-v2.jsx` → `B_SettingsV2`)

**Propósito:** usuário configura própria chave do Gemini (e opcionalmente OpenAI/Claude) com fallback para a chave do servidor.

**Layout (2 colunas):**

**Esquerda (180px sidebar):** menu vertical "Modelos de IA" (ativo) · "Conta" · "Aparência" · "Sobre".

**Direita:** conteúdo principal.

- **Bloco 1 — Modelo padrão:** dropdown grande mostrando o modelo ativo (`gemini-1.5-flash`), com mini badges indicando qual provider tem chave configurada.
- **Bloco 2 — Gemini:** card com ícone do Google.
  - Se tiver chave própria: input com chave parcialmente mascarada (`AIza...3kQp`), botão "Trocar" e "Remover".
  - Se não tiver: input vazio + placeholder "AIza..." + link "Onde encontro minha chave?" + nota "Sem chave própria, usamos a chave compartilhada do servidor (fallback)".
  - Se a chave do servidor estiver disponível: badge `fallback servidor ativo` em verde discreto. Se não: badge amarelo `sem fallback — configure uma chave`.
- **Bloco 3 — OpenAI:** mesmo padrão, mas opcional.
- **Bloco 4 — Claude:** mesmo padrão, mas opcional.
- **Bloco 5 — Validação:** botão "Testar todos os modelos" que dispara um ping rápido em cada provider configurado e mostra resultado inline (`✓ ok · 240ms`).

**Importante de copy:** deixar claro que **a chave fica salva apenas no localStorage** desse navegador e nunca é enviada ao backend exceto no momento da chamada à IA.

---

## Interactions & Behavior

### Persistência (limitação atual + solução proposta)
- **JSON do curso:** localStorage, key `coursegen.draft.<id>`. Serializado, debounced em 500ms a cada edição.
- **Arquivos `.docx`/PDF:** **mover para IndexedDB.** Hoje o repo perde a referência aos arquivos com o tempo — a solução é armazenar o Blob bruto no IndexedDB com chave `coursegen.file.<id>` e referenciá-lo do JSON via id. Quando o usuário volta a um rascunho e o IndexedDB foi limpo (devtools, modo privado, etc.), mostrar badge `arquivos expirados` na home e fluxo de "reanexar".
- **Chaves de API:** localStorage, keys `coursegen.key.gemini`, `.openai`, `.claude`. Mascarar na UI exceto no momento de configuração.

### Navegação
- Rotas sugeridas: `/` (home), `/c/[id]/upload`, `/c/[id]/review`, `/c/[id]/review/[activityId]` (drawer), `/c/[id]/file/[fileId]` (visualizador), `/c/[id]/done`, `/settings`.
- Drawer não é rota separada; é estado local controlado pelo segmento opcional. Permite deep-link.

### Animações
- Drawer entra com `transform: translateX(100%) → 0` em 220ms `cubic-bezier(0.32, 0.72, 0, 1)`.
- Background dim: `opacity 0 → 0.45` em 180ms linear.
- Toggle Blocos/JSON/Diff: cross-fade 120ms.
- Log da IA: cada linha nova entra com `opacity 0 → 1` + `translateY(4px) → 0` em 150ms.

### Validação de schema
- O JSON do curso deve ter um schema JSON válido (Moodle-compatible). Erros bloqueiam o botão "Gerar .mbz" e marcam linhas no editor JSON.

---

## State Management

Stores sugeridos (Zustand ou similar — adaptar ao que o repo já usa):

```ts
type CourseDraft = {
  id: string;
  name: string;
  code: string;
  hours: number;
  state: 'upload' | 'review' | 'generating' | 'done' | 'error';
  progress: number;        // 0–100
  json: CourseJson;        // estrutura do curso (units, activities, quizzes...)
  fileRefs: string[];      // ids dos arquivos no IndexedDB
  filesExpired: boolean;   // true se algum fileRef sumiu
  createdAt: number;
  updatedAt: number;
};

type AISettings = {
  defaultModel: 'gemini-1.5-flash' | 'gemini-1.5-pro' | 'gpt-4o' | 'claude-sonnet';
  keys: { gemini?: string; openai?: string; claude?: string };
  serverFallbackAvailable: boolean;  // vem do /api/health
};
```

---

## Files

Arquivos neste handoff (todos JSX em React 18 com Babel inline; estilos via `tokens.css`):

- `CourseGen - Dark.html` — entry point que monta o design canvas com todas as telas para comparação.
- `tokens.css` — design tokens (use a variante `.dir-b`).
- `design-canvas.jsx` — wrapper de apresentação (não precisa portar; é só pra revisão).
- `dir-b.jsx` — shell, BNav, badges, telas: Home (v1, ignorar), Upload, Review (modo JSON), Done.
- `dir-b-home.jsx` — Home v2 (usar esta).
- `dir-b-intro.jsx` — Generating, Error.
- `dir-b-v2.jsx` — Review modo Blocos, Settings v2.
- `dir-b-v3.jsx` — **Drawer da atividade (Quiz)** e **Visualizador de arquivo** — telas mais críticas.

Para visualizar todas as telas localmente: abrir `CourseGen - Dark.html` no navegador. O design canvas permite arrastar/zoom/focus em cada artboard.

---

## Próximos passos para o dev

1. Ler `tokens.css` e replicar os tokens da `.dir-b` em `tailwind.config` ou `app/globals.css` (CSS vars).
2. Criar componentes base: `<Badge>`, `<NavBar>`, `<Drawer>`, `<DocumentPreview>`, `<JsonEditor>`, `<UploadZone>`, `<AILogStream>`.
3. Migrar persistência de arquivos para IndexedDB (sugestão: lib `idb-keyval`).
4. Implementar `/settings` primeiro — destravar as chaves resolve dependência das outras telas.
5. Implementar fluxo Upload → Review (Blocos) → Done. Drawer e visualizador de arquivo vêm depois pois dependem da estrutura JSON estabilizada.
6. Stream do log da IA usa SSE no endpoint `/api/extract` (ou WebSocket se já houver infra).

Dúvidas de produto ficam com o PO (Juan). Dúvidas de design: as 3 telas mais arriscadas de implementar são **Drawer com split view**, **Visualizador com mapa de extração**, e **Settings multi-modelo com fallback** — peça mocks adicionais se precisar de variantes (mobile, estados intermediários, edge cases).
